package com.kayroot.engine

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.inputmethod.InputMethodManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** App Management + Debloat. Disable is reversible; nothing is ever removed automatically. */
class Apps(private val ctx: Context, private val access: AccessManager) {

    private val pm: PackageManager = ctx.packageManager

    companion object {
        private val PKG_RE = Regex("^[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+$")

        private val PROTECT_EXACT = setOf(
            "android", "com.android.systemui", "com.android.settings", "com.android.phone", "com.android.server.telecom",
            "com.android.shell", "com.android.vending", "com.google.android.gms", "com.google.android.gsf",
            "com.google.android.webview", "com.android.webview", "com.google.android.permissioncontroller",
            "com.android.permissioncontroller", "com.android.packageinstaller", "com.google.android.packageinstaller",
            "com.android.bluetooth", "com.android.nfc", "com.android.keychain", "com.android.certinstaller",
            "com.android.managedprovisioning", "com.android.location.fused", "com.android.emergency",
            "com.android.cellbroadcastreceiver", "com.android.stk", "com.android.mms", "com.android.dialer",
            "com.google.android.dialer", "com.google.android.apps.messaging", "com.android.carrierconfig",
            "com.android.ims", "com.android.se", "moe.shizuku.privileged.api", "com.topjohnwu.magisk"
        )
        private val PROTECT_PREFIX = listOf(
            "com.android.providers.", "com.android.server.", "com.android.inputmethod", "com.android.launcher",
            "com.google.android.networkstack", "com.android.networkstack", "com.android.wifi", "com.google.android.ext.",
            "com.google.android.inputmethod", "com.google.android.gms.", "com.google.android.setupwizard",
            "com.android.devicelock", "com.google.android.devicelock", "com.samsung.android.knox", "com.sec.android.app.launcher",
            "com.miui.home", "com.mi.android.globallauncher", "com.qualcomm.", "com.mediatek.", "org.codeaurora.",
            "com.android.cts", "com.google.android.safetycore", "com.google.android.apps.nexuslauncher"
        )

        private class Cand(val pkg: String, val label: String, val cat: String, val why: String, val tier: String)

        /** Starting points for REVIEW only. Not a promise that removal is safe on every device/ROM. */
        private val CANDS = listOf(
            Cand("com.facebook.appmanager", "Facebook App Manager", "Preinstalled", "Background installer/updater for Facebook apps.", "review"),
            Cand("com.facebook.services", "Facebook Services", "Preinstalled", "Support service for the Facebook app.", "review"),
            Cand("com.facebook.system", "Facebook Installer", "Preinstalled", "Silent installer stub shipped by some OEMs.", "review"),
            Cand("com.netflix.partner.activation", "Netflix Activation", "Preinstalled", "Partner activation stub.", "review"),
            Cand("com.netflix.mediaclient", "Netflix", "Streaming", "Streaming app. Safe if you do not use it.", "review"),
            Cand("com.amazon.mShop.android.shopping", "Amazon Shopping", "Shopping", "Shopping app preinstalled by some carriers.", "review"),
            Cand("com.linkedin.android", "LinkedIn", "Social", "Social app preinstalled on some devices.", "review"),
            Cand("com.microsoft.skydrive", "OneDrive", "Cloud", "Cloud storage app.", "review"),
            Cand("com.google.android.videos", "Google TV / Play Movies", "Google apps", "Video store app.", "review"),
            Cand("com.google.android.apps.youtube.music", "YouTube Music", "Google apps", "Music app; the YouTube app is separate.", "review"),
            Cand("com.google.android.apps.podcasts", "Google Podcasts", "Google apps", "Podcast app (discontinued by Google).", "review"),
            Cand("com.google.android.apps.tachyon", "Google Meet / Duo", "Google apps", "Video calling app.", "review"),
            Cand("com.google.android.apps.subscriptions.red", "Google One", "Google apps", "Storage subscription app.", "review"),
            Cand("com.google.android.apps.magazines", "Google News", "Google apps", "News reader.", "review"),
            Cand("com.google.android.feedback", "Google Feedback", "Telemetry", "Sends feedback reports. Review first.", "review"),
            Cand("com.miui.analytics", "MIUI Analytics", "Telemetry", "Xiaomi usage analytics.", "review"),
            Cand("com.miui.bugreport", "MIUI Bug Report", "Telemetry", "Xiaomi bug report tool.", "review"),
            Cand("com.xiaomi.mipicks", "GetApps", "Xiaomi apps", "Xiaomi app store/recommendations.", "review"),
            Cand("com.miui.yellowpage", "Yellow Pages", "Xiaomi apps", "Number lookup service.", "review"),
            Cand("com.miui.videoplayer", "Mi Video", "Xiaomi apps", "Xiaomi video app.", "review"),
            Cand("com.mi.globalbrowser", "Mi Browser", "Xiaomi apps", "Browser. Keep it if it is your only browser.", "review"),
            Cand("com.samsung.android.bixby.agent", "Bixby Voice", "Samsung apps", "Voice assistant.", "review"),
            Cand("com.samsung.android.app.spage", "Samsung Free", "Samsung apps", "Left-of-home feed.", "review"),
            Cand("com.samsung.android.game.gamehome", "Game Launcher", "Samsung apps", "Game launcher.", "review"),
            Cand("com.samsung.android.arzone", "AR Zone", "Samsung apps", "AR camera features.", "review"),
            Cand("com.google.android.gms", "Google Play services", "Critical", "Used by most apps, push notifications and sign-in. Do not disable.", "critical"),
            Cand("com.android.vending", "Google Play Store", "Critical", "App store and update channel.", "critical"),
            Cand("com.google.android.webview", "Android System WebView", "Critical", "Renders web content inside many apps.", "critical"),
            Cand("com.android.providers.media", "Media Storage", "Critical", "Core media database. Disabling breaks gallery/camera.", "critical")
        )
    }

    // ------------------------------------------------------------------ protection
    private fun protectedSet(): Set<String> {
        val s = HashSet<String>(PROTECT_EXACT)
        s.add(ctx.packageName)
        val cr = ctx.contentResolver
        try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName?.let { s.add(it) }
        } catch (_: Exception) {}
        try {
            val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.enabledInputMethodList.forEach { s.add(it.packageName) }
        } catch (_: Exception) {}
        try {
            Settings.Secure.getString(cr, "enabled_accessibility_services")?.split(':')?.forEach {
                val p = it.substringBefore('/')
                if (p.isNotBlank()) s.add(p)
            }
        } catch (_: Exception) {}
        try { (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).defaultDialerPackage?.let { s.add(it) } } catch (_: Exception) {}
        try { Telephony.Sms.getDefaultSmsPackage(ctx)?.let { s.add(it) } } catch (_: Exception) {}
        return s
    }

    private fun isProtected(pkg: String, set: Set<String>): Boolean =
        pkg in set || PROTECT_PREFIX.any { pkg.startsWith(it) }

    // ------------------------------------------------------------------ manage
    fun list(): JSONArray {
        val prot = protectedSet()
        val arr = JSONArray()
        for (ai in pm.getInstalledApplications(0)) {
            val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            arr.put(JSONObject()
                .put("n", ai.loadLabel(pm).toString())
                .put("p", ai.packageName)
                .put("s", sys)
                .put("e", ai.enabled)
                .put("l", isProtected(ai.packageName, prot)))
        }
        return arr
    }

    @Suppress("DEPRECATION")
    fun details(pkg: String): JSONObject {
        if (!PKG_RE.matches(pkg)) return JSONObject().put("ok", false).put("msg", "Invalid package")
        return try {
            val pi = pm.getPackageInfo(pkg, 0)
            val ai = pm.getApplicationInfo(pkg, 0)
            val ver = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
            val installer = try {
                if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
                else pm.getInstallerPackageName(pkg)
            } catch (e: Exception) { null }
            val sizeMb = try { File(ai.sourceDir).length() / 1048576.0 } catch (e: Exception) { 0.0 }
            val o = JSONObject()
                .put("p", pkg).put("n", ai.loadLabel(pm).toString())
                .put("ver", (pi.versionName ?: "?") + " (" + ver + ")")
                .put("sys", (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
                .put("enabled", ai.enabled)
                .put("lock", isProtected(pkg, protectedSet()))
                .put("launch", pm.getLaunchIntentForPackage(pkg) != null)
                .put("sizeMb", Math.round(sizeMb * 10) / 10.0)
                .put("installed", pi.firstInstallTime)
            o.putN("installer", installer)
            JSONObject().put("ok", true).put("data", o)
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("msg", "App not found")
        }
    }

    fun launch(pkg: String): JSONObject {
        if (!PKG_RE.matches(pkg)) return JSONObject().put("ok", false).put("msg", "Invalid package")
        val i = pm.getLaunchIntentForPackage(pkg)
            ?: return JSONObject().put("ok", false).put("msg", "This app has no launcher screen")
        return try {
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); JSONObject().put("ok", true).put("msg", "")
        } catch (e: Exception) { JSONObject().put("ok", false).put("msg", e.message ?: "Cannot launch") }
    }

    fun openSettings(pkg: String): JSONObject {
        if (!PKG_RE.matches(pkg)) return JSONObject().put("ok", false).put("msg", "Invalid package")
        return try {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().put("ok", true).put("msg", "")
        } catch (e: Exception) { JSONObject().put("ok", false).put("msg", e.message ?: "Cannot open") }
    }

    /** User apps only; Android shows its own confirmation dialog. */
    fun uninstall(pkg: String): JSONObject {
        if (!PKG_RE.matches(pkg)) return JSONObject().put("ok", false).put("msg", "Invalid package")
        val prot = protectedSet()
        if (isProtected(pkg, prot)) return JSONObject().put("ok", false).put("msg", "Protected package")
        return try {
            val ai = pm.getApplicationInfo(pkg, 0)
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0)
                return JSONObject().put("ok", false).put("msg", "System apps can only be disabled, not uninstalled")
            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            JSONObject().put("ok", true).put("msg", "Confirm in the Android dialog")
        } catch (e: Exception) { JSONObject().put("ok", false).put("msg", e.message ?: "Cannot uninstall") }
    }

    // ------------------------------------------------------------------ debloat
    fun candidates(): JSONArray {
        val prot = protectedSet()
        val arr = JSONArray()
        for (c in CANDS) {
            try {
                val ai = pm.getApplicationInfo(c.pkg, 0)
                arr.put(JSONObject().put("p", c.pkg).put("l", c.label).put("cat", c.cat).put("why", c.why)
                    .put("tier", c.tier).put("e", ai.enabled)
                    .put("lock", c.tier == "critical" || isProtected(c.pkg, prot)))
            } catch (_: Exception) { /* not installed on this device */ }
        }
        return arr
    }

    /** action = "disable" | "enable". Each package is validated, protected ones are refused, result is verified. */
    fun apply(action: String, pkgs: List<String>): JSONArray {
        val res = JSONArray()
        val prot = protectedSet()
        for (pkg in pkgs) {
            val o = JSONObject().put("p", pkg)
            if (access.mode == Mode.BASIC) { res.put(o.put("ok", false).put("msg", "Needs Shizuku or Root")); continue }
            if (!PKG_RE.matches(pkg)) { res.put(o.put("ok", false).put("msg", "Invalid package")); continue }
            if (action == "disable" && isProtected(pkg, prot)) { res.put(o.put("ok", false).put("msg", "Protected package")); continue }
            if (action != "disable" && action != "enable") { res.put(o.put("ok", false).put("msg", "Unknown action")); continue }
            val exists = try { pm.getApplicationInfo(pkg, 0); true } catch (e: Exception) { false }
            if (!exists) { res.put(o.put("ok", false).put("msg", "Not installed")); continue }
            val cmd = if (action == "disable") "pm disable-user --user 0 $pkg" else "pm enable $pkg"
            val r = access.execScript(cmd, 30_000)
            val enabledNow = try { pm.getApplicationInfo(pkg, 0).enabled } catch (e: Exception) { true }
            val verified = if (action == "disable") !enabledNow else enabledNow
            o.put("ok", verified)
            o.put("msg", if (verified) (if (action == "disable") "Disabled" else "Re-enabled")
                         else (r.err.trim().ifEmpty { r.out.trim() }.take(120).ifEmpty { "Command had no effect" }))
            res.put(o)
        }
        return res
    }
}
