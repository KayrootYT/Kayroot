/* Kayroot Engine UI v2 - talks to the Android backend through window.KayrootApp */
(function () {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const store = {
  get: (k, d) => { try { const v = localStorage.getItem('kr_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set: (k, v) => { try { localStorage.setItem('kr_' + k, JSON.stringify(v)); } catch (e) {} }
};

/* ---------------------------------------------------------------- bridge (+ browser mock for previews) */
const hasNative = !!window.KayrootApp;
if (!hasNative) installMock();
let cbN = 0;
function call(action, args) {
  return new Promise(resolve => {
    const cb = 'kcb' + (++cbN);
    const t = setTimeout(() => { delete window[cb]; resolve({ ok: false, msg: 'Timeout' }); }, 120000);
    window[cb] = r => { clearTimeout(t); delete window[cb]; resolve(r); };
    try { KayrootApp.call(action, JSON.stringify(args || {}), cb); }
    catch (e) { clearTimeout(t); resolve({ ok: false, msg: String(e) }); }
  });
}
function callFast(action, args) {
  return new Promise(resolve => {
    const cb = 'kfb' + (++cbN);
    const t = setTimeout(() => { delete window[cb]; resolve({ ok: false, msg: 'Timeout' }); }, 20000);
    window[cb] = r => { clearTimeout(t); delete window[cb]; resolve(r); };
    try { KayrootApp.fastCall(action, JSON.stringify(args || {}), cb); }
    catch (e) { clearTimeout(t); resolve({ ok: false, msg: String(e) }); }
  });
}
const native = (fn, ...a) => { try { return KayrootApp[fn](...a); } catch (e) { return null; } };
const haptic = () => { if (store.get('haptic', true)) native('haptic'); };

/* ---------------------------------------------------------------- toast + logs */
function toast(msg, type) {
  type = type || 'info';
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  const ic = type === 'success' ? 'fa-circle-check' : type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-info';
  el.innerHTML = '<i class="fas ' + ic + '"></i><span></span>';
  el.lastChild.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, 3000);
}
const clock = () => new Date().toLocaleTimeString();
function log(msg, type) {
  type = type || 'success';
  const list = $('#log-list');
  const empty = $('.empty-log', list); if (empty) empty.remove();
  const ic = type === 'error' ? 'fa-circle-xmark' : type === 'info' ? 'fa-circle-info' : 'fa-check';
  const it = document.createElement('div');
  it.className = 'log-item ' + type;
  it.innerHTML = '<i class="fas ' + ic + '"></i><span></span><time>' + clock() + '</time>';
  $('span', it).textContent = msg;
  list.prepend(it);
  while (list.children.length > 50) list.lastChild.remove();
}
function term(msg, type) {
  const t = $('#term');
  const d = $('.term-line.dim', t); if (d) d.remove();
  const l = document.createElement('div');
  l.className = 'term-line ' + (type || '');
  l.innerHTML = '<span>&gt;</span><i class="fas ' + (type === 'error' ? 'fa-circle-xmark' : 'fa-circle-check') + '"></i><span></span>';
  l.lastChild.textContent = clock() + ': ' + msg;
  t.appendChild(l); t.scrollTop = t.scrollHeight;
  while (t.children.length > 40) t.firstChild.remove();
}
const report = (ok, msg, name) => { toast(msg, ok ? 'success' : 'error'); setTimeout(loadLog, 400); };

/* ---------------------------------------------------------------- navigation */
const PAGES = ['home', 'monitor', 'apps', 'quick', 'adv', 'settings'];
let page = 'home';
function go(p) {
  if (p === page && $('#page-' + p).classList.contains('active')) return;
  page = p;
  $$('.page').forEach(x => x.classList.toggle('active', x.id === 'page-' + p));
  $$('#bnav button').forEach(b => b.classList.toggle('active', b.dataset.page === p));
  
  window.scrollTo({ top: 0, behavior: 'smooth' });
  haptic();
  if (p === 'adv') { refreshToggles(); refreshGov(); }
  if (p === 'quick') { refreshStats(); loadLog(); refreshExtra(); refreshCooldown(); }
  if (p === 'monitor') { refreshBattery(); refreshOverlay(); }
  if (p === 'apps') loadApps(false);
  if (p === 'settings') { refreshPerms(); }
  if (p !== 'monitor' && monTimer) { /* keep running only while visible */ stopMonitor(); }
}
$$('#bnav button').forEach(b => b.addEventListener('click', () => go(b.dataset.page)));
function placeIndicator() {
  const nav = $('#bnav'); const w = (nav.clientWidth - 8) / PAGES.length;
  const i = $('#nav-ind'); i.style.width = (w - 4) + 'px'; i.style.left = '6px';
  i.style.transform = 'translateX(' + PAGES.indexOf(page) * (w) + 'px)';
}
const _go = go;
go = function (p) { _go(p); placeIndicator(); };
window.addEventListener('resize', placeIndicator);

/* ---------------------------------------------------------------- state */
let status = { mode: 'basic' };
const rank = () => status.mode === 'root' ? 2 : status.mode === 'shizuku' ? 1 : 0;

function applyStatus(s) {
  status = s || status;
  $$('#mode-seg button').forEach(b => b.classList.toggle('active', b.dataset.mode === status.mode));
  let h;
  if (status.mode === 'basic') {
    if (!status.shizukuInstalled) h = 'Basic mode: only <b>Cleaner</b> &amp; <b>Cooling</b> work. Install <b>Shizuku</b> for profiles, Optimizer &amp; system controls (no root needed).';
    else if (!status.shizukuRunning) h = 'Shizuku is installed but <b>not running</b>. Start it (Wireless debugging), then tap <b>Shizuku</b>.';
    else h = 'Tap <b>Shizuku</b> and allow permission to unlock Pro features.';
  } else if (status.mode === 'shizuku') {
    h = status.shizukuGranted ? 'Shizuku active: profiles, deep cleaner, optimizer &amp; system controls enabled.'
                              : 'Shizuku mode selected but the service is <b>not running</b>. Start Shizuku again.';
  } else h = 'Root active: CPU governors, bypass charging, I/O &amp; kernel tweaks unlocked.';
  $('#access-hint').innerHTML = h;
  $('#device-line').textContent = (status.device || '') + ' | SoC: ' + (status.soc || '?') + ' | API ' + (status.sdk || '?');
  setProfileUI(status.profile || '', status.ai);
  lockToggles();
  $('#set-boot').checked = !!status.boot;
  renderEngine();
  const dbg = $('#set-debug'); if (dbg) dbg.checked = !!status.debug;
}
window.onKayrootStatus = applyStatus;

$$('#mode-seg button').forEach(b => b.addEventListener('click', () => {
  haptic(); log('Switching access mode: ' + b.dataset.mode, 'info');
  native('selectMode', b.dataset.mode);
}));
$('#open-shizuku').addEventListener('click', () => native('openShizuku'));

/* ---------------------------------------------------------------- profiles */
const PROFILES = [
  { id: 'auto', name: 'Auto AI Mode', desc: 'Adaptive rules engine: reacts to heat, battery & app', icon: 'fa-robot', c: '#f5c518' },
  { id: 'game', name: 'Game Booster', desc: 'Performance mode. More heat and battery use', icon: 'fa-gamepad', c: '#ff3b3b' },
  { id: 'daytoday', name: 'Multitasking', desc: 'Balanced for everyday multitasking', icon: 'fa-list-check', c: '#29b6f6' },
  { id: 'powersave', name: 'Power Saving', desc: 'Power Save: longer battery, slower animations', icon: 'fa-battery-half', c: '#2ed573' }
];
const tint = (hex, a) => { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; };
const light = hex => { const n = parseInt(hex.slice(1), 16); const m = v => Math.round(v + (255 - v) * .3); return 'rgb(' + m(n >> 16) + ',' + m((n >> 8) & 255) + ',' + m(n & 255) + ')'; };
function paint(el, c) { el.style.setProperty('--c', c); el.style.setProperty('--c40', tint(c, .4)); el.style.setProperty('--c14', tint(c, .14)); el.style.setProperty('--cl', light(c)); }
const pl = $('#profile-list');
PROFILES.forEach(p => {
  const d = document.createElement('div');
  d.className = 'pcard'; d.dataset.id = p.id; paint(d, p.c);
  d.innerHTML = '<div class="pi"><i class="fas ' + p.icon + '"></i></div><div class="pt"><h3>' + p.name + '</h3><p>' + p.desc + '</p></div><div class="sel">SELECT</div>';
  d.addEventListener('click', () => selectProfile(p.id));
  pl.appendChild(d);
});
function setProfileUI(id, ai) {
  $$('.pcard').forEach(c => { const on = c.dataset.id === id; c.classList.toggle('on', on); $('.sel', c).textContent = on ? 'APPLIED' : 'SELECT'; });
  const p = PROFILES.find(x => x.id === id);
  let name = p ? p.name : 'Not selected';
  if (id === 'auto' && ai && ai.profile) name += ' (' + ({ game: 'Game', daytoday: 'Multitasking', powersave: 'Power Saving' }[ai.profile] || ai.profile) + ')';
  $('#cur-profile').textContent = name;
}
async function selectProfile(id) {
  const card = $('.pcard[data-id="' + id + '"]');
  if (card.classList.contains('busy')) return;
  haptic(); card.classList.add('busy');
  const r = await call('profile', { name: id });
  card.classList.remove('busy');
  const nm = PROFILES.find(x => x.id === id).name;
  if (r.ok) { setProfileUI(id, null); report(true, nm + ' applied'); }
  else report(false, r.msg || 'Failed');
  refreshStatus();
}
$('#reset-btn').addEventListener('click', async () => {
  haptic(); const r = await call('reset');
  if (r.ok) { setProfileUI('', null); report(true, 'Profiles reset'); } else report(false, r.msg || 'Reset failed');
  refreshStatus();
});

/* ---------------------------------------------------------------- quick menu */
const QUICK = [
  { id: 'clean', name: 'CLEANER', icon: 'fa-memory', c: '#a855f7', ok: 'Cleaner finished' },
  { id: 'cool', name: 'COOLING', icon: 'fa-fan', c: '#29b6f6', ok: 'Cooling finished' },
  { id: 'optimize', name: 'OPTIMIZER', icon: 'fa-rocket', c: '#2ed573', ok: 'Optimizer started' },
  { id: 'netrefresh', name: 'NET REFRESH', icon: 'fa-tower-broadcast', c: '#ffa502', ok: 'Network refreshed' }
];
const qg = $('#quick-grid');
QUICK.forEach(q => {
  const b = document.createElement('button');
  b.className = 'qbtn'; paint(b, q.c);
  b.innerHTML = '<div class="qi"><i class="fas ' + q.icon + '"></i></div>' + q.name;
  b.addEventListener('click', async () => {
    haptic(); b.classList.add('busy');
    const r = await call(q.id);
    b.classList.remove('busy');
    report(r.ok, r.ok ? (r.msg || q.ok) : (r.msg || 'Failed'));
    refreshStats();
  });
  qg.appendChild(b);
});
$('#clear-log').addEventListener('click', async () => { haptic(); await call('log_clear'); loadLog(); });

/* ---------------------------------------------------------------- live monitor */
const RINGS = [
  { id: 'bat', label: 'Battery', c: '#2ed573' }, { id: 'ram', label: 'RAM', c: '#29b6f6' },
  { id: 'sto', label: 'Storage', c: '#a855f7' }, { id: 'tmp', label: 'Temp', c: '#ffa502' }
];
const CIRC = 2 * Math.PI * 30;
$('#rings').innerHTML = RINGS.map(r =>
  '<div class="ring" id="ring-' + r.id + '" style="--rc:' + r.c + '"><svg viewBox="0 0 80 80"><circle class="bg" cx="40" cy="40" r="30"/><circle class="fg" cx="40" cy="40" r="30" stroke-dasharray="' + CIRC + '" stroke-dashoffset="' + CIRC + '"/></svg><div class="val">--</div><small>' + r.label + '</small></div>').join('');
function setRing(id, pct, text, color) {
  const el = $('#ring-' + id); if (!el) return;
  const p = Math.max(0, Math.min(100, pct));
  $('.fg', el).style.strokeDashoffset = CIRC * (1 - p / 100);
  if (color) el.style.setProperty('--rc', color);
  $('.val', el).textContent = text;
}
function refreshStats() {
  const raw = native('getStats'); if (!raw) return;
  let s; try { s = JSON.parse(raw); } catch (e) { return; }
  const b = s.battery || {};
  setRing('bat', b.level, b.level + '%', b.level <= 20 ? '#ff4d6d' : '#2ed573');
  setRing('ram', s.ram.pct, s.ram.pct + '%', s.ram.pct > 85 ? '#ff4d6d' : '#29b6f6');
  setRing('sto', s.storage.pct, s.storage.pct + '%');
  setRing('tmp', Math.min(100, (b.temp / 55) * 100), b.temp.toFixed(1) + '\u00b0', b.temp >= 42 ? '#ff4d6d' : b.temp >= 38 ? '#ffa502' : '#2ed573');
  $('#monitor-line').textContent = (b.charging ? 'Charging' : 'Discharging') + ' \u2022 ' + (b.voltage / 1000).toFixed(2) + ' V \u2022 RAM ' + s.ram.usedMb + '/' + s.ram.totalMb + ' MB \u2022 Free ' + s.storage.freeGb.toFixed(1) + ' GB';
}
setInterval(() => { if (!document.hidden && page === 'quick') refreshStats(); }, 3000);

/* ---------------------------------------------------------------- system controls */
const TOGGLES = [
  { key: 'dnd', icon: 'fa-bell-slash', title: 'Do Not Disturb', on: 'DND is active', off: 'DND is inactive', ic: ['fa-bell-slash', 'fa-bell'], need: 1 },
  { key: 'bypass', icon: 'fa-bolt', title: 'Bypass Charging Mode', on: 'Bypass is active', off: 'Bypass is inactive', ic: ['fa-bolt', 'fa-bolt'], need: 2 },
  { key: 'battery_saver', icon: 'fa-battery-quarter', title: 'Battery Saver', on: 'Battery saver is on', off: 'Battery saver is off', ic: ['fa-leaf', 'fa-leaf'], need: 1 },
  { key: 'hi_refresh', icon: 'fa-gauge-high', title: 'Max Refresh Rate', on: 'Max refresh locked', off: 'Refresh rate is auto', ic: ['fa-display', 'fa-display'], need: 1 },
  { key: 'fast_anim', icon: 'fa-wand-magic-sparkles', title: 'Fast Animations', on: 'Animations 0.5x', off: 'Animations 1x', ic: ['fa-forward-fast', 'fa-forward'], need: 1 },
  { key: 'stay_awake', icon: 'fa-plug-circle-bolt', title: 'Stay Awake (Charging)', on: 'Screen stays on', off: 'Normal screen timeout', ic: ['fa-sun', 'fa-moon'], need: 1 }
];
let tState = {};
const tl = $('#toggle-list');
TOGGLES.forEach(t => {
  const d = document.createElement('div');
  d.className = 'sys'; d.id = 'sys-' + t.key;
  d.innerHTML = '<h3><i class="fas ' + t.icon + '"></i>' + t.title + (t.need === 2 ? ' <span class="badge">ROOT</span>' : '') + '</h3>' +
    '<div class="row"><div class="state"><i class="fas ' + t.ic[1] + '"></i><span>--</span></div><label class="switch"><input type="checkbox"><span></span></label></div><div class="need" hidden></div>';
  tl.appendChild(d);
  const inp = $('input', d);
  inp.addEventListener('change', async () => {
    const want = inp.checked;
    if (rank() < t.need) { inp.checked = !want; toast(t.need === 2 ? 'Root required for this control' : 'Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error'); return; }
    haptic(); inp.disabled = true;
    const r = await call('toggle_set', { key: t.key, on: want });
    inp.disabled = false;
    const label = t.title.split(' (')[0].toUpperCase();
    term(r.ok ? label + (want ? ' enabled' : ' disabled') : label + ' failed: ' + (r.msg || 'error'), r.ok ? '' : 'error');
    if (!r.ok) toast(r.msg || 'Failed', 'error');
    refreshToggles();
  });
});
function renderToggle(t) {
  const d = $('#sys-' + t.key); if (!d) return;
  const st = tState[t.key]; const on = !!(st && st.on); const sup = !st || st.supported !== false;
  d.classList.toggle('on', on);
  $('.state i', d).className = 'fas ' + t.ic[on ? 0 : 1];
  $('.state span', d).textContent = sup ? (on ? t.on : t.off) : 'Not supported on this device';
  const inp = $('input', d); inp.checked = on; inp.disabled = !sup;
  const need = $('.need', d);
  const locked = rank() < t.need;
  d.classList.toggle('locked', locked);
  need.hidden = !locked;
  need.textContent = locked ? (t.need === 2 ? 'Needs Root access' : 'Needs Shizuku or Root') : '';
}
const lockToggles = () => TOGGLES.forEach(renderToggle);
async function refreshToggles() {
  const r = await call('toggle_get_all');
  if (r && r.data) { tState = r.data; lockToggles(); }
}
setInterval(() => { if (!document.hidden && page === 'adv') refreshToggles(); }, 6000);

/* governor */
async function refreshGov() {
  const hint = $('#gov-hint'), chips = $('#gov-chips');
  if (rank() < 2) { hint.innerHTML = 'CPU governor control needs <b>Root</b>.'; chips.innerHTML = ''; return; }
  const r = await call('gov_info');
  if (!r.ok || !r.data) { hint.textContent = r.msg || 'Governor info unavailable'; chips.innerHTML = ''; return; }
  hint.innerHTML = 'Current: <b>' + r.data.current + '</b>';
  chips.innerHTML = '';
  (r.data.available || []).forEach(g => {
    const c = document.createElement('button');
    c.className = 'chip' + (g === r.data.current ? ' on' : ''); c.textContent = g;
    c.addEventListener('click', async () => {
      haptic(); const x = await call('gov_set', { name: g });
      term(x.ok ? 'GOVERNOR set to ' + g : 'GOVERNOR failed: ' + (x.msg || 'error'), x.ok ? '' : 'error');
      refreshGov();
    });
    chips.appendChild(c);
  });
}

/* ---------------------------------------------------------------- settings */
const THEMES = [['#00f5d4', '#9d4edd'], ['#ff4dd2', '#7b2cff'], ['#39ff14', '#00b4d8'], ['#ffb300', '#ff3b3b']];
const th = $('#themes');
function applyTheme(i) {
  const [a, b] = THEMES[i] || THEMES[0];
  document.documentElement.style.setProperty('--accent', a);
  document.documentElement.style.setProperty('--accent2', b);
  $$('.tdot').forEach((d, k) => d.classList.toggle('on', k === i));
}
THEMES.forEach((t, i) => {
  const d = document.createElement('button'); d.className = 'tdot'; d.style.setProperty('--tc', t[0]);
  d.addEventListener('click', () => { store.set('theme', i); applyTheme(i); haptic(); });
  th.appendChild(d);
});
applyTheme(store.get('theme', 0));
$('#set-rain').checked = store.get('rain', true);
$('#set-haptic').checked = store.get('haptic', true);
$('#set-rain').addEventListener('change', e => { store.set('rain', e.target.checked); rainOn = e.target.checked; $('#rain').style.display = rainOn ? '' : 'none'; });
$('#set-haptic').addEventListener('change', e => store.set('haptic', e.target.checked));
$('#set-boot').addEventListener('change', async e => {
  const r = await call('boot_set', { on: e.target.checked });
  if (!r.ok) { e.target.checked = !e.target.checked; toast(r.msg || 'Failed', 'error'); }
});


/* ================================================================ v2.2 modules */
const esc = x => String(x).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmtAgo = t => { if (!t) return 'never'; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? 'just now' : m < 60 ? m + ' min ago' : m < 1440 ? Math.round(m / 60) + ' h ago' : Math.round(m / 1440) + ' d ago'; };
const na = (v, f) => (v === null || v === undefined) ? null : f(v);

function modal(title, html, okText, cancelText) {
  return new Promise(res => {
    const m = $('#modal'), ok = $('#modal-ok'), no = $('#modal-no');
    $('#modal-title').textContent = title; $('#modal-body').innerHTML = html;
    ok.textContent = okText || 'OK'; no.textContent = cancelText || 'Cancel'; no.hidden = cancelText === null;
    const done = v => { m.classList.remove('show'); ok.onclick = no.onclick = null; res(v); };
    ok.onclick = () => done(true); no.onclick = () => done(false);
    m.classList.add('show');
  });
}

/* ---------- history (persisted natively) ---------- */
async function loadLog() {
  const r = await callFast('log_get'); if (!r.ok || !r.data) return;
  const list = $('#log-list'); list.innerHTML = '';
  if (!r.data.length) list.innerHTML = '<div class="empty-log">No activity yet</div>';
  r.data.forEach(e => {
    const it = document.createElement('div'); it.className = 'log-item ' + (e.ok ? 'success' : 'error');
    it.innerHTML = '<i class="fas ' + (e.ok ? 'fa-check' : 'fa-circle-xmark') + '"></i><span></span><time>' + new Date(e.t).toLocaleTimeString() + '</time>';
    $('span', it).textContent = e.m; list.appendChild(it);
  });
  const hr = $('#home-recent'); if (hr) {
    hr.innerHTML = r.data.length ? '' : '<div class="empty-log">No operations yet</div>';
    r.data.slice(0, 4).forEach(e => { const d = document.createElement('div'); d.className = 'log-item ' + (e.ok ? 'success' : 'error'); d.innerHTML = '<i class="fas ' + (e.ok ? 'fa-check' : 'fa-circle-xmark') + '"></i><span></span><time>' + new Date(e.t).toLocaleTimeString() + '</time>'; $('span', d).textContent = e.m; hr.appendChild(d); });
  }
}
$('#hist-clear').addEventListener('click', async () => { haptic(); await call('log_clear'); loadLog(); toast('History cleared', 'success'); });
$('#set-debug').addEventListener('change', e => call('debug_set', { on: e.target.checked }));

/* ---------- AI engine card ---------- */
function renderEngine() {
  const el = $('#engine-kv'); if (!el) return;
  const ai = status.ai || {};
  const modeName = { power: 'Power Save', auto: 'Auto (adaptive rules)', perf: 'Performance' }[status.aiMode] || 'Not selected';
  const row = (k, v, c) => '<div><span>' + k + '</span><b class="' + (c || '') + '">' + esc(v) + '</b></div>';
  el.innerHTML = row('Engine', ai.on ? 'Running' : 'Stopped', ai.on ? 'good' : '') + row('Mode', modeName) +
    row('Last decision', ai.on ? ((ai.reason || 'Waiting...')) : '--') +
    row('Last optimization', fmtAgo(status.lastOpt)) +
    row('Shizuku', status.shizukuGranted ? 'Connected' : status.shizukuRunning ? 'Permission needed' : status.shizukuInstalled ? 'Not running' : 'Not installed', status.shizukuGranted ? 'good' : '') +
    row('Root', status.rootOk ? 'Available' : status.rootChecked ? 'Not available' : 'Not checked', status.rootOk ? 'good' : '');
}
$('#ai-stop').addEventListener('click', async () => { haptic(); const r = await call('ai_stop'); report(r.ok, r.msg || 'Stopped'); refreshStatus(); });
$('#ai-restart').addEventListener('click', async () => { haptic(); const r = await call('ai_restart'); report(r.ok, r.msg || 'Failed'); refreshStatus(); });

/* ---------- performance monitor ---------- */
let monTimer = null, monInt = 2000; const hist = [];
const MON_INTS = [[1000, '1 s'], [2000, '2 s'], [5000, '5 s']];
MON_INTS.forEach(([v, t]) => { const c = document.createElement('button'); c.className = 'chip' + (v === monInt ? ' on' : ''); c.textContent = t; c.dataset.v = v;
  c.addEventListener('click', () => { monInt = v; $$('#mon-int .chip').forEach(x => x.classList.toggle('on', +x.dataset.v === v)); if (monTimer) { stopMonitor(); startMonitor(); } haptic(); }); $('#mon-int').appendChild(c); });
const metric = (k, v) => '<div class="metric"><small>' + k + '</small>' + (v === null ? '<b class="na">N/A</b>' : '<b>' + esc(v) + '</b>') + '</div>';
function drawGraph() {
  const c = $('#cpu-graph'); const w = c.clientWidth || 300; c.width = w; c.height = 90; const x = c.getContext('2d');
  x.clearRect(0, 0, w, 90); x.strokeStyle = 'rgba(255,255,255,.08)'; x.beginPath(); [22, 45, 67].forEach(y => { x.moveTo(0, y); x.lineTo(w, y); }); x.stroke();
  const pts = hist.filter(h => h !== null); if (pts.length < 2) { x.fillStyle = 'rgba(220,245,255,.5)'; x.font = '11px monospace'; x.fillText(hist.length && pts.length === 0 ? 'CPU graph: N/A on this access level' : 'collecting samples...', 10, 50); return; }
  x.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#0f8'; x.lineWidth = 2; x.beginPath();
  hist.forEach((v, i) => { const px = i * (w / 59), py = 88 - (v === null ? 0 : v) * 0.86; i ? x.lineTo(px, py) : x.moveTo(px, py); }); x.stroke();
}
let monBusy = false;
async function monTick() {
  if (monBusy || document.hidden) return; monBusy = true;
  const r = await callFast('mon_sample'); monBusy = false;
  if (!r.ok || !r.data) return; const d = r.data, b = d.battery, m = d.ram;
  hist.push(d.cpuPct === null ? null : d.cpuPct); if (hist.length > 60) hist.shift();
  const mx = d.freqMhz && d.freqMhz.length ? Math.max.apply(null, d.freqMhz) : null;
  $('#mon-grid').innerHTML =
    metric('CPU usage', na(d.cpuPct, v => v.toFixed(0) + '%')) + metric('CPU cores / max clock', d.cores + (mx ? ' / ' + mx + ' MHz' : ' / N/A')) +
    metric('GPU usage', na(d.gpuPct, v => v.toFixed(0) + '%')) + metric('GPU clock', na(d.gpuMhz, v => v.toFixed(0) + ' MHz')) +
    metric('CPU temp', na(d.cpuTemp, v => v.toFixed(1) + '\u00b0C')) + metric('Battery temp', na(b.tempC, v => v.toFixed(1) + '\u00b0C')) +
    metric('Thermal status', d.thermal === 'N/A' ? null : d.thermal) + metric('Memory pressure', m.pressure) +
    metric('RAM used', m.usedMb + ' / ' + m.totalMb + ' MB') + metric('Cached / Swap', (m.cachedMb == null ? 'N/A' : m.cachedMb + ' MB') + ' / ' + (m.swapTotalMb == null ? 'N/A' : (m.swapTotalMb - m.swapFreeMb) + ' MB'));
  $('#mon-note').textContent = d.cpuPct === null && d.mode === 'basic' ? 'CPU/GPU usage needs Shizuku or Root: Android blocks it for normal apps.' : 'Sampling every ' + (monInt / 1000) + ' s. FPS is in the overlay below.';
  drawGraph();
}
function startMonitor() { monTick(); monTimer = setInterval(monTick, monInt); $('#mon-toggle').innerHTML = '<i class="fa-solid fa-stop"></i> Stop'; }
function stopMonitor() { clearInterval(monTimer); monTimer = null; const t = $('#mon-toggle'); if (t) t.innerHTML = '<i class="fa-solid fa-play"></i> Start'; }
$('#mon-toggle').addEventListener('click', () => { haptic(); if (monTimer) stopMonitor(); else { hist.length = 0; call('mon_reset'); startMonitor(); } });
document.addEventListener('visibilitychange', () => { if (document.hidden && monTimer) stopMonitor(); });

/* ---------- battery ---------- */
async function refreshBattery() {
  const r = await callFast('batt_info'); if (!r.ok || !r.data) return; const b = r.data;
  $('#bat-grid').innerHTML = metric('Level', b.level + '%') + metric('State', b.status + (b.plugged !== 'No' ? ' (' + b.plugged + ')' : '')) +
    metric('Voltage', (b.voltageMv / 1000).toFixed(2) + ' V') + metric('Temperature', na(b.tempC, v => v.toFixed(1) + '\u00b0C')) +
    metric('Current (approx.)', na(b.currentMa, v => v.toFixed(0) + ' mA')) + metric('Power (approx.)', na(b.powerW, v => v.toFixed(1) + ' W')) +
    metric('Health (Android)', b.health) + metric('Capacity (estimate)', na(b.estFullMah, v => '~' + v.toFixed(0) + ' mAh')) +
    metric('Charge now', na(b.chargeNowMah, v => v.toFixed(0) + ' mAh')) + metric('Cycles', na(b.cycles, v => String(v)));
  $('#bat-opt-txt').textContent = b.battOptIgnored ? 'Battery use: unrestricted (tap to review)' : 'Battery use: optimized (tap to allow background)';
}
$('#bat-opt').addEventListener('click', () => native('openSystem', 'battery'));

/* ---------- overlay ---------- */
const OV = [['fps', 'FPS'], ['cpu', 'CPU'], ['gpu', 'GPU'], ['ram', 'RAM'], ['bat', 'Battery'], ['temp', 'Temp'], ['pwr', 'Power']];
let ovCfg = { stats: 'fps,cpu,ram,bat,temp', running: false };
OV.forEach(([k, t]) => { const c = document.createElement('button'); c.className = 'chip'; c.textContent = t; c.dataset.k = k;
  c.addEventListener('click', () => { const set = new Set(ovCfg.stats.split(',').filter(Boolean)); set.has(k) ? set.delete(k) : set.add(k); ovCfg.stats = [...set].join(','); paintOv(); call('overlay_cfg_set', { stats: ovCfg.stats }); haptic(); }); $('#ov-stats').appendChild(c); });
function paintOv() {
  const on = new Set(ovCfg.stats.split(',')); $$('#ov-stats .chip').forEach(c => c.classList.toggle('on', on.has(c.dataset.k)));
  $('#ov-toggle').innerHTML = ovCfg.running ? '<i class="fa-solid fa-stop"></i> Stop overlay' : '<i class="fa-solid fa-play"></i> Start overlay';
  $('#ov-alpha-v').textContent = $('#ov-alpha').value + '%'; $('#ov-size-v').textContent = $('#ov-size').value + ' sp'; $('#ov-int-v').textContent = ($('#ov-int').value / 1000).toFixed(2) + ' s';
}
async function refreshOverlay() {
  const r = await callFast('overlay_cfg_get'); if (!r.ok || !r.data) return; ovCfg = r.data;
  $('#ov-alpha').value = ovCfg.alpha; $('#ov-size').value = ovCfg.size; $('#ov-int').value = ovCfg.interval; paintOv();
}
[['#ov-alpha', 'alpha'], ['#ov-size', 'size'], ['#ov-int', 'interval']].forEach(([sel, key]) => { const el = $(sel); el.addEventListener('input', paintOv); el.addEventListener('change', () => call('overlay_cfg_set', { [key]: +el.value })); });
$('#ov-toggle').addEventListener('click', async () => {
  haptic();
  if (ovCfg.running) { const r = await call('overlay_stop'); report(r.ok, r.msg || 'Stopped'); }
  else {
    const r = await call('overlay_start');
    if (r.perm) { const go = await modal('Permission needed', 'The overlay draws on top of other apps, so Android asks you to allow <b>Display over other apps</b> for Kayroot. Nothing else is accessed.', 'Open settings'); if (go) native('openSystem', 'overlay'); }
    else report(r.ok, r.msg || 'Failed');
  }
  setTimeout(refreshOverlay, 600);
});

/* ---------- apps: manage ---------- */
let appsAll = [], appsLoaded = false, appFilter = 'user', excl = new Set();
const AFILTERS = [['user', 'User'], ['system', 'System'], ['disabled', 'Disabled'], ['all', 'All'], ['excl', 'Excluded']];
AFILTERS.forEach(([k, t]) => { const c = document.createElement('button'); c.className = 'chip' + (k === appFilter ? ' on' : ''); c.textContent = t; c.dataset.k = k;
  c.addEventListener('click', () => { appFilter = k; $$('#app-filter .chip').forEach(x => x.classList.toggle('on', x.dataset.k === k)); renderApps(); haptic(); }); $('#app-filter').appendChild(c); });
$$('#app-tabs button').forEach(b => b.addEventListener('click', () => {
  $$('#app-tabs button').forEach(x => x.classList.toggle('active', x === b));
  $('#tab-manage').hidden = b.dataset.tab !== 'manage'; $('#tab-debloat').hidden = b.dataset.tab !== 'debloat';
  if (b.dataset.tab === 'debloat') loadDebloat(); haptic();
}));
async function loadExcl() { const r = await callFast('excl_get'); if (r.ok && r.data) excl = new Set(r.data); }
async function loadApps(force) {
  if (appsLoaded && !force) return;
  $('#app-count').textContent = 'Loading apps...';
  const r = await call('apps_list'); if (!r.ok || !r.data) { $('#app-count').textContent = r.msg || 'Failed to load apps'; return; }
  appsAll = r.data; appsLoaded = true; renderApps();
}
$('#app-q').addEventListener('input', () => renderApps());
function renderApps() {
  const q = $('#app-q').value.trim().toLowerCase();
  let l = appsAll.filter(a => (appFilter === 'all') || (appFilter === 'user' && !a.s) || (appFilter === 'system' && a.s) || (appFilter === 'disabled' && !a.e) || (appFilter === 'excl' && excl.has(a.p)));
  if (q) l = l.filter(a => a.n.toLowerCase().includes(q) || a.p.toLowerCase().includes(q));
  l.sort((a, b) => a.n.localeCompare(b.n));
  $('#app-count').textContent = l.length + ' apps' + (l.length > 150 ? ' (showing first 150, use search)' : '');
  const box = $('#app-list'); box.innerHTML = '';
  if (!l.length) { box.innerHTML = '<div class="empty-log">No apps match</div>'; return; }
  l.slice(0, 150).forEach(a => {
    const d = document.createElement('div'); d.className = 'arow';
    d.innerHTML = '<div class="ai"></div><div class="at"><b></b><small></small></div><span></span>';
    $('.ai', d).textContent = (a.n || '?').trim().charAt(0).toUpperCase(); $('b', d).textContent = a.n; $('small', d).textContent = a.p;
    $('span', d).innerHTML = (a.s ? '<span class="pill">SYS</span>' : '') + (a.e ? '' : '<span class="pill bad">OFF</span>') + (a.l ? '<span class="pill shizuku">LOCK</span>' : '') + (excl.has(a.p) ? '<span class="pill good">EXCL</span>' : '');
    d.addEventListener('click', () => openApp(a)); box.appendChild(d);
  });
}
async function openApp(a) {
  haptic(); const sh = $('#sheet'); $('#sheet-title').textContent = a.n; $('#sheet-body').textContent = 'Loading...'; $('#sheet-actions').innerHTML = ''; sh.classList.add('show');
  const r = await call('app_details', { pkg: a.p }); if (!r.ok) { $('#sheet-body').textContent = r.msg || 'Failed'; return; } const d = r.data;
  $('#sheet-body').innerHTML = '<div class="kv"><div><span>Package</span><b>' + esc(d.p) + '</b></div><div><span>Version</span><b>' + esc(d.ver) + '</b></div><div><span>Type</span><b>' + (d.sys ? 'System app' : 'User app') + '</b></div><div><span>State</span><b class="' + (d.enabled ? 'good' : 'bad') + '">' + (d.enabled ? 'Enabled' : 'Disabled') + '</b></div><div><span>Size (APK)</span><b>' + d.sizeMb + ' MB</b></div><div><span>Installer</span><b>' + esc(d.installer || 'unknown') + '</b></div></div>' + (d.lock ? '<p class="hint warn">Protected package: it cannot be disabled or uninstalled from here.</p>' : '');
  const acts = $('#sheet-actions');
  const add = (label, icon, fn, dis) => { const b = document.createElement('button'); b.className = 'btn'; b.innerHTML = '<i class="fa-solid ' + icon + '"></i> ' + label; b.disabled = !!dis; b.addEventListener('click', fn); acts.appendChild(b); };
  add('Launch', 'fa-play', async () => { const x = await call('app_launch', { pkg: d.p }); if (!x.ok) toast(x.msg, 'error'); }, !d.launch);
  add('App settings', 'fa-gear', () => call('app_settings', { pkg: d.p }));
  add(excl.has(d.p) ? 'Remove exclusion' : 'Exclude from cleaner', 'fa-shield', async () => { excl.has(d.p) ? excl.delete(d.p) : excl.add(d.p); await call('excl_set', { list: [...excl] }); toast('Exclusion list updated', 'success'); $('#sheet').classList.remove('show'); renderApps(); });
  if (!d.sys) add('Uninstall', 'fa-trash', async () => { if (await modal('Uninstall ' + d.n + '?', 'Android will ask you to confirm. App data will be lost.', 'Continue')) { const x = await call('app_uninstall', { pkg: d.p }); toast(x.msg || (x.ok ? 'Opened' : 'Failed'), x.ok ? 'info' : 'error'); } }, d.lock);
  add(d.enabled ? 'Disable' : 'Enable', d.enabled ? 'fa-ban' : 'fa-circle-check', async () => {
    if (rank() < 1) return toast('Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error');
    if (!await modal((d.enabled ? 'Disable ' : 'Enable ') + d.n + '?', d.enabled ? 'The app will stop running and disappear from the launcher. You can re-enable it here at any time.' : 'The app will be re-enabled.', 'Confirm')) return;
    const x = await call('debloat_apply', { action: d.enabled ? 'disable' : 'enable', pkgs: [d.p] }); const row = x.data && x.data[0];
    report(!!(row && row.ok), row ? d.n + ': ' + row.msg : 'Failed'); $('#sheet').classList.remove('show'); loadApps(true); debloatLoaded = false;
  }, d.lock && d.enabled);
}
$('#sheet-close').addEventListener('click', () => $('#sheet').classList.remove('show'));
$('#sheet').addEventListener('click', e => { if (e.target.id === 'sheet') $('#sheet').classList.remove('show'); });

/* ---------- apps: debloat ---------- */
let debloatLoaded = false, dlist = []; const picked = new Set();
async function loadDebloat() {
  if (debloatLoaded) return; const box = $('#debloat-list'); box.innerHTML = '<div class="empty-log">Scanning installed packages...</div>';
  const r = await call('debloat_list'); if (!r.ok) { box.innerHTML = '<div class="empty-log">' + esc(r.msg || 'Failed') + '</div>'; return; }
  dlist = r.data; debloatLoaded = true; picked.clear(); renderDebloat();
}
function renderDebloat() {
  const box = $('#debloat-list'); box.innerHTML = ''; if (!dlist.length) { box.innerHTML = '<div class="empty-log">None of the known candidates are installed here.</div>'; $('#debloat-n').textContent = 0; return; }
  [['review', 'SAFE TO REVIEW'], ['critical', 'CRITICAL / PROTECTED (locked)']].forEach(([tier, title]) => {
    const items = dlist.filter(x => x.tier === tier); if (!items.length) return;
    const h = document.createElement('div'); h.className = 'dgroup'; h.textContent = title; box.appendChild(h);
    items.forEach(x => {
      const d = document.createElement('label'); d.className = 'drow' + (x.lock ? ' lock' : '');
      d.innerHTML = '<input type="checkbox"><div class="at"><b></b> <span class="pill"></span><small class="why"></small><small class="pk"></small></div>';
      const cb = $('input', d); cb.disabled = x.lock; cb.checked = picked.has(x.p);
      $('b', d).textContent = x.l; $('.pill', d).textContent = x.e ? x.cat : 'DISABLED'; if (!x.e) $('.pill', d).classList.add('bad');
      $('.why', d).textContent = x.why; $('.pk', d).textContent = x.p;
      cb.addEventListener('change', () => { cb.checked ? picked.add(x.p) : picked.delete(x.p); $('#debloat-n').textContent = picked.size; haptic(); });
      box.appendChild(d);
    });
  });
  $('#debloat-n').textContent = picked.size;
}
$('#debloat-preview').addEventListener('click', async () => {
  if (!picked.size) return toast('Select at least one app', 'info');
  if (rank() < 1) return toast('Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error');
  const plan = [...picked].map(p => dlist.find(x => x.p === p)).filter(Boolean);
  const dis = plan.filter(x => x.e), en = plan.filter(x => !x.e);
  const li = a => '<ul>' + a.map(x => '<li><b>' + esc(x.l) + '</b><br><small>' + esc(x.p) + '</small></li>').join('') + '</ul>';
  const html = (dis.length ? '<b>Will be disabled (reversible):</b>' + li(dis) : '') + (en.length ? '<b>Will be re-enabled:</b>' + li(en) : '') + '<p class="hint warn" style="text-align:left">To undo later: select the same app here, or open it in MANAGE and tap Enable.</p>';
  if (!await modal('Planned actions', html, 'Execute')) return;
  haptic(); let lines = [];
  for (const [action, arr] of [['disable', dis], ['enable', en]]) {
    if (!arr.length) continue; const r = await call('debloat_apply', { action, pkgs: arr.map(x => x.p) });
    (r.data || []).forEach(x => lines.push((x.ok ? '\u2705 ' : '\u274C ') + esc(x.p) + ' \u2014 ' + esc(x.msg)));
  }
  await modal('Result', '<pre>' + lines.join('\n') + '</pre>', 'Done', null);
  debloatLoaded = false; appsLoaded = false; loadDebloat(); setTimeout(loadLog, 300);
});

/* ---------- quick: cleaning / extra optimization / cooldown ---------- */
function renderClean(s) {
  const el = $('#clean-kv'); if (!el || !s) return;
  const row = (k, v) => '<div><span>' + k + '</span><b>' + v + '</b></div>';
  el.innerHTML = row('RAM', s.ram.usedMb + ' / ' + s.ram.totalMb + ' MB') + row('Storage used', (s.storage.totalGb - s.storage.freeGb).toFixed(1) + ' / ' + s.storage.totalGb.toFixed(1) + ' GB') + row('Storage free', s.storage.freeGb.toFixed(1) + ' GB');
}
const _rs = refreshStats; refreshStats = function () { _rs(); const raw = native('getStats'); if (raw) { try { renderClean(JSON.parse(raw)); } catch (e) {} } };
$('#log-view').addEventListener('click', async () => { haptic(); const r = await call('log_view'); await modal('Recent warnings & errors', '<pre>' + esc(r.data || r.msg || 'No output') + '</pre>', 'Close', null); });
$('#log-clear-sys').addEventListener('click', async () => {
  if (!await modal('Clear logcat buffers?', 'This empties the on-device debug log buffers. Android security/audit logs are not touched, and nothing else is deleted.', 'Clear')) return;
  const r = await call('logcat_clear'); report(r.ok, r.msg || 'Failed');
});

const EXTRA = [
  { id: 'bgdexopt', name: 'Background dexopt', desc: 'Runs Android\'s own optimization job for apps that need it.' },
  { id: 'speedprofile', name: 'Recompile apps (speed-profile)', desc: 'Profile-guided ART recompile of all apps. Slow, heavy on CPU and battery.' },
  { id: 'fstrim', name: 'Trim storage', desc: 'Asks the filesystem to discard unused blocks. Result depends on the device.' }
];
const xl = $('#extra-list');
EXTRA.forEach(x => { const d = document.createElement('div'); d.className = 'xrow'; d.id = 'x-' + x.id; d.innerHTML = '<div class="at"><b>' + x.name + '</b><small>' + x.desc + '</small><small class="xs"></small></div><button class="mini-btn"><i class="fa-solid fa-play"></i> Run</button>';
  $('button', d).addEventListener('click', async () => {
    if (rank() < 1) return toast('Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error');
    haptic(); let r = await call('extra_run', { kind: x.id });
    if (r.confirm) { if (!await modal('Run again?', esc(r.msg), 'Run anyway')) return; r = await call('extra_run', { kind: x.id, force: true }); }
    report(r.ok, r.msg || 'Failed'); refreshExtra();
  }); xl.appendChild(d); });
async function refreshExtra() {
  for (const x of EXTRA) { if (x.id === 'fstrim') continue; const r = await callFast('extra_status', { kind: x.id }); const s = $('#x-' + x.id + ' .xs'); if (!s || !r.ok) continue;
    s.textContent = r.state === 'running' ? 'Running... (progress is not measurable, status updates when it ends)' : r.state.startsWith('done:0') ? 'Last run finished OK' : r.state.startsWith('done:') ? 'Last run ended with code ' + r.state.slice(5) : (r.last ? 'Last started ' + fmtAgo(r.last) : '');
  }
  const t = await callFast('extra_sched_get'); if (t.ok) { $('#extra-sched').checked = !!t.on; $('#extra-last').textContent = 'Last background dexopt: ' + fmtAgo(t.lastRun) + '. Android decides the exact time, so it is never guaranteed to run at a fixed hour.'; }
  if (EXTRA.some(() => true) && $('#x-bgdexopt .xs').textContent.startsWith('Running')) setTimeout(() => { if (page === 'quick') refreshExtra(); }, 5000);
}
$('#extra-sched').addEventListener('change', async e => { const r = await call('extra_sched', { on: e.target.checked }); if (!r.ok) e.target.checked = !e.target.checked; report(r.ok, r.msg || 'Failed'); });
$('#extra-reset').addEventListener('click', async () => { haptic(); const r = await call('reset'); if (r.ok) setProfileUI('', null); report(r.ok, r.ok ? 'Optimization settings reset' : (r.msg || 'Reset failed')); });

$('#cd-run').addEventListener('click', async () => {
  const steps = $$('[data-cd]').filter(i => i.checked).map(i => i.dataset.cd); if (!steps.length) return toast('Pick at least one step', 'info');
  const risky = steps.includes('airplane');
  const ok = await modal('Emergency cooldown', '<ul>' + steps.map(s => '<li>' + ({ overlay: 'Stop the stats overlay', ai: 'Stop the Auto AI loop', bgkill: 'Close background apps', battsaver: 'Turn battery saver on', airplane: '<b>Airplane mode ON</b>' }[s]) + '</li>').join('') + '</ul>' +
    (risky ? '<p class="hint warn" style="text-align:left"><b>Airplane mode will cut calls, mobile data, Wi-Fi and notifications</b> until restored.</p>' : '') + '<p>Temporary changes are restored after 10 minutes or when you tap Restore.</p>', 'Cool down');
  if (!ok) return; haptic(); const r = await call('cooldown', { steps }); report(r.ok, r.msg || 'Failed'); refreshCooldown();
});
$('#cd-restore').addEventListener('click', async () => { const r = await call('cooldown_restore'); report(r.ok, r.msg || 'Failed'); refreshCooldown(); });
async function refreshCooldown() { const r = await callFast('cooldown_get'); $('#cd-restore').hidden = !(r.ok && r.data && r.data.length); }

/* ---------- settings: permissions + capability scan ---------- */
const PERM_ACT = { overlay: () => native('openSystem', 'overlay'), notif: () => native('openSystem', 'notif'), battery: () => native('openSystem', 'battery'), shizuku: () => native('openShizuku'), root: () => native('selectMode', 'root') };
async function refreshPerms() {
  const r = await callFast('perm_status'); if (!r.ok || !r.data) return; const box = $('#perm-list'); box.innerHTML = '';
  r.data.forEach(p => { const d = document.createElement('div'); d.className = 'crow';
    d.innerHTML = '<div class="top"><b></b><span class="pill ' + (p.ok ? 'good' : 'warn') + '">' + (p.ok ? 'GRANTED' : 'NOT GRANTED') + '</span></div><small></small>';
    $('b', d).textContent = p.name; $('small', d).textContent = p.why;
    if (!p.ok) { const b = document.createElement('button'); b.className = 'mini-btn'; b.style.marginTop = '8px'; b.textContent = p.id === 'root' ? 'Check root' : p.id === 'shizuku' ? 'Open Shizuku' : 'Open settings'; b.addEventListener('click', PERM_ACT[p.id]); d.appendChild(b); }
    box.appendChild(d); });
}
const ST = { supported: 'SUPPORTED', partial: 'PARTIAL', permission: 'PERMISSION REQUIRED', shizuku: 'SHIZUKU REQUIRED', root: 'ROOT REQUIRED', unsupported: 'KERNEL/DEVICE UNSUPPORTED', failed: 'FAILED', untested: 'NOT TESTED' };
$('#caps-scan').addEventListener('click', async () => {
  haptic(); const b = $('#caps-scan'); b.disabled = true; b.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Scanning...';
  const r = await call('caps_scan'); b.disabled = false; b.innerHTML = '<i class="fa-solid fa-magnifying-glass-chart"></i> Run scan';
  if (!r.ok || !r.data) return toast(r.msg || 'Scan failed', 'error');
  const box = $('#caps-list'); box.innerHTML = '';
  r.data.forEach(c => { const d = document.createElement('div'); d.className = 'crow'; d.innerHTML = '<div class="top"><b></b><span class="pill ' + c.status + '">' + ST[c.status] + '</span></div><small></small>'; $('b', d).textContent = c.name; $('small', d).textContent = c.detail; box.appendChild(d); });
});

/* ---------------------------------------------------------------- matrix rain */
let rainOn = store.get('rain', true);
(function rain() {
  const c = $('#rain'), x = c.getContext('2d'); let cols, drops;
  function size() { c.width = innerWidth; c.height = innerHeight; cols = Math.floor(c.width / 14); drops = Array.from({ length: cols }, () => Math.random() * -50); }
  size(); addEventListener('resize', size);
  if (!rainOn) c.style.display = 'none';
  setInterval(() => {
    if (!rainOn || document.hidden) return;
    x.fillStyle = 'rgba(4,5,13,.12)'; x.fillRect(0, 0, c.width, c.height);
    x.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#0f8'; x.font = '13px monospace';
    for (let i = 0; i < cols; i++) {
      x.fillText(Math.random() > .5 ? '1' : '0', i * 14, drops[i] * 14);
      if (drops[i] * 14 > c.height && Math.random() > .975) drops[i] = 0;
      drops[i]++;
    }
  }, 60);
})();

/* ---------------------------------------------------------------- boot */
async function refreshStatus() {
  const raw = native('getStatus'); if (raw) { try { applyStatus(JSON.parse(raw)); } catch (e) {} }
}
setInterval(() => { if (!document.hidden && page === 'home') refreshStatus(); }, 4000);
window.addEventListener('load', () => {
  refreshStatus(); refreshStats(); placeIndicator(); loadLog(); loadExcl();
  setTimeout(() => $('#loading').classList.add('hide'), 900);
});

/* ---------------------------------------------------------------- mock (browser preview only) */
function installMock() {
  const s = { mode: 'shizuku', shizukuInstalled: true, shizukuRunning: true, shizukuGranted: true, sdk: 34, device: 'Preview Phone', soc: 'Snapdragon', profile: 'daytoday', boot: false };
  const t = { dnd: { on: false }, bypass: { on: true, supported: true }, battery_saver: { on: false }, hi_refresh: { on: true }, fast_anim: { on: false }, stay_awake: { on: false } };
  window.KayrootApp = {
    getStatus: () => JSON.stringify(s),
    getStats: () => JSON.stringify({ battery: { level: 62, temp: 36.4, charging: false, voltage: 4012 }, ram: { usedMb: 4210, totalMb: 7600, pct: 55 }, storage: { freeGb: 88.2, totalGb: 256, pct: 66 } }),
    selectMode: m => { s.mode = m; window.onKayrootStatus(s); },
    openShizuku() {}, haptic() {}, openSystem() {},
    fastCall: (a, args, cb) => setTimeout(() => {
      let r = { ok: true, msg: '' };
      if (a === 'mon_sample') r.data = { cores: 8, cpuPct: 20 + Math.random() * 40, freqMhz: [1800, 2400, 2800], gpuPct: null, gpuMhz: null, cpuTemp: 41.2, thermal: 'None', ram: { totalMb: 7600, availMb: 3300, usedMb: 4300, pct: 56, cachedMb: 2100, swapTotalMb: 2048, swapFreeMb: 1900, pressure: 'Normal' }, battery: { tempC: 36.4 }, mode: 'shizuku' };
      else if (a === 'batt_info') r.data = { level: 62, voltageMv: 4012, tempC: 36.4, status: 'Discharging', plugged: 'No', health: 'Good', currentMa: -420, powerW: 1.7, chargeNowMah: 2900, estFullMah: 4680, cycles: null, battOptIgnored: false };
      else if (a === 'overlay_cfg_get') r.data = { running: false, perm: true, stats: 'fps,cpu,ram,bat,temp', alpha: 80, size: 12, interval: 1500 };
      else if (a === 'log_get') r.data = [{ t: Date.now(), m: 'Profile daytoday', ok: true }];
      else if (a === 'perm_status') r.data = [{ id: 'overlay', name: 'Display over other apps', why: 'Overlay only', ok: false }, { id: 'shizuku', name: 'Shizuku', why: 'Unlocks pro features', ok: true }];
      else if (a === 'cooldown_get' || a === 'excl_get') r.data = [];
      else if (a === 'extra_status') { r.state = ''; r.last = 0; }
      else if (a === 'extra_sched_get') { r.on = false; r.lastRun = 0; }
      window[cb](r);
    }, 200),
    call: (a, args, cb) => setTimeout(() => {
      const A = JSON.parse(args); let r = { ok: true, msg: '' };
      if (a === 'toggle_get_all') r.data = t;
      else if (a === 'toggle_set') { t[A.key].on = A.on; }
      else if (a === 'gov_info') r.data = { current: 'schedutil', available: ['performance', 'schedutil', 'powersave', 'conservative'] };
      else if (a === 'profile') s.profile = A.name;
      else if (a === 'apps_list') r.data = [{ n: 'Chrome', p: 'com.android.chrome', s: false, e: true, l: false }, { n: 'Facebook Services', p: 'com.facebook.services', s: true, e: true, l: false }];
      else if (a === 'debloat_list') r.data = [{ p: 'com.facebook.services', l: 'Facebook Services', cat: 'Preinstalled', why: 'Support service for the Facebook app.', tier: 'review', e: true, lock: false }, { p: 'com.google.android.gms', l: 'Google Play services', cat: 'Critical', why: 'Do not disable.', tier: 'critical', e: true, lock: true }];
      window[cb](r);
    }, 400)
  };
}
})();
