# Kayroot Engine – Android App (Non-Root + Shizuku + Root)

Magisk module **Kayroot Engine 2.0** ka same UI + animations, ab ek normal APK ke roop me.
WebUI (`app/src/main/assets/webroot`) original hai; backend Kotlin me likha gaya hai.

## APK kaise banaye (GitHub)
1. Naya GitHub repo banao aur is poore folder ka content push karo (`main` branch).
2. **Actions** tab -> *Build APK* khud chalega (ya *Run workflow* dabao).
3. Build khatam hone par run ke **Artifacts** se `KayrootEngine-apk` download karo -> `KayrootEngine-v2.0.apk`.
4. Release banana ho to tag push karo: `git tag v2.0 && git push --tags` (APK Releases me aa jayega).

**Signing (optional but recommended):** Repo Settings -> Secrets me `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`,
`KEY_ALIAS`, `KEY_PASSWORD` daal do, taaki har update same signature se bane. Secrets na ho to
CI temporary key bana leta hai (APK install hoga, par update ke liye uninstall karna pad sakta hai).

Local build: Android Studio me folder open karo, ya `gradle :app:assembleRelease` (JDK 17, Gradle 8.9).

## Access modes (UI ke upar "Access Mode" card)
| Feature | Basic (no root) | Shizuku (Pro) | Root (Pro Max) |
|---|:--:|:--:|:--:|
| Cleaner | bg apps close + own cache | **sab apps ka cache trim** + bg kill | + `/data/.../cache` wipe, drop_caches |
| Cooling | bg apps close | bg kill-all | + CPU governor low-power 30s |
| Optimizer | – | bg dexopt + speed-profile recompile | + I/O, F2FS, VM, sched tweaks, fstrim |
| GameBooster | – | fixed-performance-mode, battery saver off | + CPU governor `performance` |
| Multitasking | – | balanced mode | + governor `schedutil` |
| PowerSaving | – | battery saver ON, animations 0.5x | + governor `powersave` |
| Boot par profile re-apply | – | – | ✅ |

**Zaroori sach:** CPU governor / sysfs / kernel (`/sys`, `/proc/sys`) tweaks ke liye root chahiye. Shizuku (ADB shell)
unhe likh nahi sakta, isliye Shizuku mode me sirf system-level tweaks chalte hain. Kuch commands (e.g. `cmd power
set-fixed-performance-mode-enabled`) sirf Android 12+ par hote hain; jo device par support na ho woh chupchap skip hote hain.

## Shizuku use karna
1. Shizuku app install karo -> Wireless debugging se start karo.
2. Kayroot app -> **Access Mode -> Shizuku** -> permission Allow.

## Project structure
```
app/src/main/
  assets/webroot/        original UI (index.html, body.css, core.js) + app.css/app-bridge.js (Access Mode card)
  assets/scripts/        asli tweaks (shell_*.sh = Shizuku level, root_*.sh = root level)
  aidl/.../IShellService Shizuku user-service interface
  java/com/kayroot/engine/
    MainActivity.kt      WebView + JS bridges (window.ksu, KayrootApp)
    CommandRouter.kt     core.js ke commands (su -c Kroot --game ...) ko allow-list karke Tweaks se jodta hai
    Tweaks.kt            profiles, cleaner, cooling, optimizer
    AccessManager.kt     Basic / Shizuku / Root execution
    ShellService.kt      Shizuku process me chalta hai (shell uid)
    BootReceiver.kt      root mode: boot ke baad profile re-apply
```

## Notes
* Original `Kroot` / `Quick` binaries packed/encrypted hain, unka code padha nahi ja sakta. Unke features UI + `service.sh`
  ke hisaab se naye scripts me **re-implement** kiye gaye hain (behaviour bilkul identical hone ki guarantee nahi).
* `service.sh` ke risky hisse (logd/statsd stop, `/data/local/tmp` & `/cache` wipe, dalvik-cache delete) jaan-boojh kar nahi liye.
* UI CDN (FontAwesome, Audiowide, Remixicon, particles.js) se load hoti hai -> animations/icons ke liye internet chahiye.
  Offline chahiye to wo files `assets/webroot/assets/` me rakh kar `index.html` ke links badal do.
* UI/branding (logo, UPI, Telegram links) original Kayroot author ke hain. Public release se pehle unki permission lo
  ya links/branding badal do.
