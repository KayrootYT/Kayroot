# Cleaner (root) - ported from service.sh of the Magisk module
sync
w /proc/sys/vm/drop_caches 3
w /proc/sys/vm/compact_memory 1
for d in /data/user/*/*/cache /data/user_de/*/*/cache /sdcard/Android/data/*/cache; do
  [ -d "$d" ] && rm -rf "$d"/* 2>/dev/null
done
rm -rf /data/system/dropbox/* /data/tombstones/* /data/anr/* 2>/dev/null
echo "ok: app caches + crash logs wiped"
