# Cleaner (Shizuku level): trims every app's cache + closes cached background processes
ok pm trim-caches 999G
ok am kill-all
rm -rf /sdcard/Download/.trash/* /sdcard/Download/*.tmp 2>/dev/null && echo "ok: download temp files removed"
