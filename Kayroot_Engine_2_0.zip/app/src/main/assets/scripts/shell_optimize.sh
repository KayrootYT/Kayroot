# Optimizer (Shizuku level)
ok cmd package bg-dexopt-job
# Full profile-guided recompile of all apps; takes minutes, so run it detached in the background.
nohup sh -c 'cmd package compile -m speed-profile -a' >/dev/null 2>&1 &
echo "ok: background dexopt (speed-profile) started"
ok am kill-all
