# Cooling (Shizuku level): less background load = less heat
ok am kill-all
