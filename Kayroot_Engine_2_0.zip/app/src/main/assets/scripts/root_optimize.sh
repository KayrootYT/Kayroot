# Optimizer (root) - ported from service.sh of the Magisk module
# --- Storage (UFS / eMMC) read-ahead + queue depth
for q in /sys/block/sd*/queue; do
  [ -d "$q" ] || continue
  [ "$(cat "$q/../removable" 2>/dev/null)" = "1" ] && continue
  w "$q/read_ahead_kb" 2048
  w "$q/nr_requests" 256
done
for q in /sys/block/mmcblk*/queue; do
  [ -d "$q" ] || continue
  [ "$(cat "$q/../removable" 2>/dev/null)" = "1" ] && continue
  w "$q/read_ahead_kb" 1024
  w "$q/nr_requests" 128
done

# --- F2FS garbage collection
for m in /sys/fs/f2fs/*; do
  [ -d "$m" ] || continue
  w "$m/gc_urgent_sleep_time" 50
  w "$m/gc_min_sleep_time" 50
  w "$m/gc_max_sleep_time" 500
  w "$m/iostat_enable" 0
  w "$m/gc_idle" 0
  w "$m/atgc_enabled" 1
  w "$m/discard_granularity" 1
done

# --- Kernel / scheduler
w /proc/sys/kernel/random/read_wakeup_threshold 64
w /proc/sys/kernel/random/write_wakeup_threshold 128
w /proc/sys/debug/exception-trace 0
w /proc/sys/kernel/printk "0 0 0 0"
w /proc/sys/kernel/panic 0
w /proc/sys/kernel/panic_on_oops 0
w /proc/sys/kernel/sched_child_runs_first 0
w /proc/sys/kernel/sched_schedstats 0
w /proc/sys/kernel/sched_min_granularity_ns 1000000
w /proc/sys/kernel/sched_wakeup_granularity_ns 2000000
w /proc/sys/kernel/sched_migration_cost_ns 5000000
w /proc/sys/kernel/sched_autogroup_enabled 0
w /proc/sys/kernel/sched_tunable_scaling 0

# --- Memory + TRIM
sync
w /proc/sys/vm/drop_caches 3
w /proc/sys/vm/compact_memory 1
ok fstrim -v /data
ok fstrim -v /cache
