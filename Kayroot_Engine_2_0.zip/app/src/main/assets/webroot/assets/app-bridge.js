/* Kayroot Engine (Android) - Access Mode bridge. core.js talks to window.ksu (native exec bridge). */
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var last = null;

  function log(msg, type, icon) {
    try { if (typeof logger !== 'undefined') logger.addLog(msg, type || 'info', icon || 'ri-information-line'); } catch (e) {}
  }

  window.onKayrootStatus = function (s) {
    last = s;
    var label = { basic: 'Basic (No Root)', shizuku: 'Shizuku (Pro)', root: 'Root (Pro Max)' }[s.mode] || s.mode;
    var v = $('access-mode-value'); if (v) v.textContent = label;
    ['basic', 'shizuku', 'root'].forEach(function (m) {
      var b = $('mode-' + m); if (b) b.classList.toggle('active', s.mode === m);
    });
    var hint = '';
    if (s.mode === 'basic') {
      if (!s.shizukuInstalled) hint = 'Basic mode: only <b>Cleaner</b> and <b>Cooling</b> work. Install <b>Shizuku</b> for profiles &amp; Optimizer (no root needed).';
      else if (!s.shizukuRunning) hint = 'Shizuku is installed but <b>not running</b>. Start it (Wireless debugging) then tap <b>Shizuku</b>.';
      else if (!s.shizukuGranted) hint = 'Tap <b>Shizuku</b> and allow permission to unlock Pro features.';
      else hint = 'Shizuku is ready. Tap <b>Shizuku</b> to enable Pro features.';
    } else if (s.mode === 'shizuku') {
      hint = s.shizukuGranted ? 'Shizuku active: profiles, deep cleaner, optimizer &amp; cooling run with ADB-level access.'
                              : 'Shizuku mode selected but service is <b>not running</b>. Start Shizuku again.';
    } else {
      hint = 'Root active: full kernel tweaks (CPU governors, I/O, F2FS, VM) are enabled.';
    }
    var h = $('access-hint'); if (h) h.innerHTML = hint;
    var d = $('device-line');
    if (d) d.textContent = (s.device || '') + ' | SoC: ' + (s.soc || 'unknown') + ' | Android API ' + (s.sdk || '?');
  };

  function init() {
    if (!window.KayrootApp) return;
    ['basic', 'shizuku', 'root'].forEach(function (m) {
      var b = $('mode-' + m);
      if (b) b.addEventListener('click', function () {
        log('Switching access mode: ' + m, 'info', 'ri-shield-flash-line');
        KayrootApp.selectMode(m);
      });
    });
    try { window.onKayrootStatus(JSON.parse(KayrootApp.getStatus())); } catch (e) {}
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
