/* Kayroot Engine UI v2 - talks to the Android backend through window.KayrootApp */
(function () {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const store = {
  get: (k, d) => { try { const v = localStorage.getItem('kr_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set: (k, v) => { try { localStorage.setItem('kr_' + k, JSON.stringify(v)); } catch (e) {} }
};

/* ---------------------------------------------------------------- bridge (+ browser mock for previews) */
const hasNative = !!window.KayrootApp;
if (!hasNative) installMock();
let cbN = 0;
function call(action, args) {
  return new Promise(resolve => {
    const cb = 'kcb' + (++cbN);
    const t = setTimeout(() => { delete window[cb]; resolve({ ok: false, msg: 'Timeout' }); }, 120000);
    window[cb] = r => { clearTimeout(t); delete window[cb]; resolve(r); };
    try { KayrootApp.call(action, JSON.stringify(args || {}), cb); }
    catch (e) { clearTimeout(t); resolve({ ok: false, msg: String(e) }); }
  });
}
const native = (fn, ...a) => { try { return KayrootApp[fn](...a); } catch (e) { return null; } };
const haptic = () => { if (store.get('haptic', true)) native('haptic'); };

/* ---------------------------------------------------------------- toast + logs */
function toast(msg, type) {
  type = type || 'info';
  const el = document.createElement('div');
  el.className = 'toast ' + type;
  const ic = type === 'success' ? 'fa-circle-check' : type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-info';
  el.innerHTML = '<i class="fas ' + ic + '"></i><span></span>';
  el.lastChild.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, 3000);
}
const clock = () => new Date().toLocaleTimeString();
function log(msg, type) {
  type = type || 'success';
  const list = $('#log-list');
  const empty = $('.empty-log', list); if (empty) empty.remove();
  const ic = type === 'error' ? 'fa-circle-xmark' : type === 'info' ? 'fa-circle-info' : 'fa-check';
  const it = document.createElement('div');
  it.className = 'log-item ' + type;
  it.innerHTML = '<i class="fas ' + ic + '"></i><span></span><time>' + clock() + '</time>';
  $('span', it).textContent = msg;
  list.prepend(it);
  while (list.children.length > 50) list.lastChild.remove();
}
function term(msg, type) {
  const t = $('#term');
  const d = $('.term-line.dim', t); if (d) d.remove();
  const l = document.createElement('div');
  l.className = 'term-line ' + (type || '');
  l.innerHTML = '<span>&gt;</span><i class="fas ' + (type === 'error' ? 'fa-circle-xmark' : 'fa-circle-check') + '"></i><span></span>';
  l.lastChild.textContent = clock() + ': ' + msg;
  t.appendChild(l); t.scrollTop = t.scrollHeight;
  while (t.children.length > 40) t.firstChild.remove();
}
const report = (ok, msg, name) => { toast(msg, ok ? 'success' : 'error'); log(msg, ok ? 'success' : 'error'); };

/* ---------------------------------------------------------------- navigation */
const PAGES = ['home', 'quick', 'adv', 'about'];
let page = 'home';
function go(p) {
  if (p === page && $('#page-' + p).classList.contains('active')) return;
  page = p;
  $$('.page').forEach(x => x.classList.toggle('active', x.id === 'page-' + p));
  $$('#bnav button').forEach(b => b.classList.toggle('active', b.dataset.page === p));
  $('#nav-ind').style.transform = 'translateX(' + PAGES.indexOf(p) * 100 + '%)';
  window.scrollTo({ top: 0, behavior: 'smooth' });
  haptic();
  if (p === 'adv') { refreshToggles(); refreshGov(); }
  if (p === 'quick') refreshStats();
}
$$('#bnav button').forEach(b => b.addEventListener('click', () => go(b.dataset.page)));
function placeIndicator() {
  const nav = $('#bnav'); const w = (nav.clientWidth - 16) / 4;
  const i = $('#nav-ind'); i.style.width = (w - 4) + 'px'; i.style.left = '10px';
  i.style.transform = 'translateX(' + PAGES.indexOf(page) * (w) + 'px)';
}
const _go = go;
go = function (p) { _go(p); placeIndicator(); };
window.addEventListener('resize', placeIndicator);

/* ---------------------------------------------------------------- state */
let status = { mode: 'basic' };
const rank = () => status.mode === 'root' ? 2 : status.mode === 'shizuku' ? 1 : 0;

function applyStatus(s) {
  status = s || status;
  $$('#mode-seg button').forEach(b => b.classList.toggle('active', b.dataset.mode === status.mode));
  let h;
  if (status.mode === 'basic') {
    if (!status.shizukuInstalled) h = 'Basic mode: only <b>Cleaner</b> &amp; <b>Cooling</b> work. Install <b>Shizuku</b> for profiles, Optimizer &amp; system controls (no root needed).';
    else if (!status.shizukuRunning) h = 'Shizuku is installed but <b>not running</b>. Start it (Wireless debugging), then tap <b>Shizuku</b>.';
    else h = 'Tap <b>Shizuku</b> and allow permission to unlock Pro features.';
  } else if (status.mode === 'shizuku') {
    h = status.shizukuGranted ? 'Shizuku active: profiles, deep cleaner, optimizer &amp; system controls enabled.'
                              : 'Shizuku mode selected but the service is <b>not running</b>. Start Shizuku again.';
  } else h = 'Root active: CPU governors, bypass charging, I/O &amp; kernel tweaks unlocked.';
  $('#access-hint').innerHTML = h;
  $('#device-line').textContent = (status.device || '') + ' | SoC: ' + (status.soc || '?') + ' | API ' + (status.sdk || '?');
  setProfileUI(status.profile || '', status.ai);
  lockToggles();
  $('#set-boot').checked = !!status.boot;
}
window.onKayrootStatus = applyStatus;

$$('#mode-seg button').forEach(b => b.addEventListener('click', () => {
  haptic(); log('Switching access mode: ' + b.dataset.mode, 'info');
  native('selectMode', b.dataset.mode);
}));
$('#open-shizuku').addEventListener('click', () => native('openShizuku'));

/* ---------------------------------------------------------------- profiles */
const PROFILES = [
  { id: 'auto', name: 'Auto AI Mode', desc: 'Smart AI based on real-time usage', icon: 'fa-robot', c: '#f5c518' },
  { id: 'game', name: 'Game Booster', desc: 'Say goodbye to lag. Say hello to victory', icon: 'fa-gamepad', c: '#ff3b3b' },
  { id: 'daytoday', name: 'Multitasking', desc: 'Handles multitasking better than you', icon: 'fa-list-check', c: '#29b6f6' },
  { id: 'powersave', name: 'Power Saving', desc: 'Longer Battery life, slower rider', icon: 'fa-battery-half', c: '#2ed573' }
];
const tint = (hex, a) => { const n = parseInt(hex.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; };
const light = hex => { const n = parseInt(hex.slice(1), 16); const m = v => Math.round(v + (255 - v) * .3); return 'rgb(' + m(n >> 16) + ',' + m((n >> 8) & 255) + ',' + m(n & 255) + ')'; };
function paint(el, c) { el.style.setProperty('--c', c); el.style.setProperty('--c40', tint(c, .4)); el.style.setProperty('--c14', tint(c, .14)); el.style.setProperty('--cl', light(c)); }
const pl = $('#profile-list');
PROFILES.forEach(p => {
  const d = document.createElement('div');
  d.className = 'pcard'; d.dataset.id = p.id; paint(d, p.c);
  d.innerHTML = '<div class="pi"><i class="fas ' + p.icon + '"></i></div><div class="pt"><h3>' + p.name + '</h3><p>' + p.desc + '</p></div><div class="sel">SELECT</div>';
  d.addEventListener('click', () => selectProfile(p.id));
  pl.appendChild(d);
});
function setProfileUI(id, ai) {
  $$('.pcard').forEach(c => { const on = c.dataset.id === id; c.classList.toggle('on', on); $('.sel', c).textContent = on ? 'APPLIED' : 'SELECT'; });
  const p = PROFILES.find(x => x.id === id);
  let name = p ? p.name : 'Not selected';
  if (id === 'auto' && ai && ai.profile) name += ' (' + ({ game: 'Game', daytoday: 'Multitasking', powersave: 'Power Saving' }[ai.profile] || ai.profile) + ')';
  $('#cur-profile').textContent = name;
}
async function selectProfile(id) {
  const card = $('.pcard[data-id="' + id + '"]');
  if (card.classList.contains('busy')) return;
  haptic(); card.classList.add('busy');
  const r = await call('profile', { name: id });
  card.classList.remove('busy');
  const nm = PROFILES.find(x => x.id === id).name;
  if (r.ok) { setProfileUI(id, null); report(true, nm + ' applied'); }
  else report(false, r.msg || 'Failed');
  refreshStatus();
}
$('#reset-btn').addEventListener('click', async () => {
  haptic(); const r = await call('reset');
  if (r.ok) { setProfileUI('', null); report(true, 'Profiles reset'); } else report(false, r.msg || 'Reset failed');
  refreshStatus();
});

/* ---------------------------------------------------------------- quick menu */
const QUICK = [
  { id: 'clean', name: 'CLEANER', icon: 'fa-memory', c: '#a855f7', ok: 'Cleaner finished' },
  { id: 'cool', name: 'COOLING', icon: 'fa-fan', c: '#29b6f6', ok: 'Cooling finished' },
  { id: 'optimize', name: 'OPTIMIZER', icon: 'fa-rocket', c: '#2ed573', ok: 'Optimizer started' },
  { id: 'netrefresh', name: 'NET REFRESH', icon: 'fa-tower-broadcast', c: '#ffa502', ok: 'Network refreshed' }
];
const qg = $('#quick-grid');
QUICK.forEach(q => {
  const b = document.createElement('button');
  b.className = 'qbtn'; paint(b, q.c);
  b.innerHTML = '<div class="qi"><i class="fas ' + q.icon + '"></i></div>' + q.name;
  b.addEventListener('click', async () => {
    haptic(); b.classList.add('busy');
    const r = await call(q.id);
    b.classList.remove('busy');
    report(r.ok, r.ok ? (r.msg || q.ok) : (r.msg || 'Failed'));
    refreshStats();
  });
  qg.appendChild(b);
});
$('#clear-log').addEventListener('click', () => { $('#log-list').innerHTML = '<div class="empty-log">No activity yet</div>'; haptic(); });

/* ---------------------------------------------------------------- live monitor */
const RINGS = [
  { id: 'bat', label: 'Battery', c: '#2ed573' }, { id: 'ram', label: 'RAM', c: '#29b6f6' },
  { id: 'sto', label: 'Storage', c: '#a855f7' }, { id: 'tmp', label: 'Temp', c: '#ffa502' }
];
const CIRC = 2 * Math.PI * 30;
$('#rings').innerHTML = RINGS.map(r =>
  '<div class="ring" id="ring-' + r.id + '" style="--rc:' + r.c + '"><svg viewBox="0 0 80 80"><circle class="bg" cx="40" cy="40" r="30"/><circle class="fg" cx="40" cy="40" r="30" stroke-dasharray="' + CIRC + '" stroke-dashoffset="' + CIRC + '"/></svg><div class="val">--</div><small>' + r.label + '</small></div>').join('');
function setRing(id, pct, text, color) {
  const el = $('#ring-' + id); if (!el) return;
  const p = Math.max(0, Math.min(100, pct));
  $('.fg', el).style.strokeDashoffset = CIRC * (1 - p / 100);
  if (color) el.style.setProperty('--rc', color);
  $('.val', el).textContent = text;
}
function refreshStats() {
  const raw = native('getStats'); if (!raw) return;
  let s; try { s = JSON.parse(raw); } catch (e) { return; }
  const b = s.battery || {};
  setRing('bat', b.level, b.level + '%', b.level <= 20 ? '#ff4d6d' : '#2ed573');
  setRing('ram', s.ram.pct, s.ram.pct + '%', s.ram.pct > 85 ? '#ff4d6d' : '#29b6f6');
  setRing('sto', s.storage.pct, s.storage.pct + '%');
  setRing('tmp', Math.min(100, (b.temp / 55) * 100), b.temp.toFixed(1) + '\u00b0', b.temp >= 42 ? '#ff4d6d' : b.temp >= 38 ? '#ffa502' : '#2ed573');
  $('#monitor-line').textContent = (b.charging ? 'Charging' : 'Discharging') + ' \u2022 ' + (b.voltage / 1000).toFixed(2) + ' V \u2022 RAM ' + s.ram.usedMb + '/' + s.ram.totalMb + ' MB \u2022 Free ' + s.storage.freeGb.toFixed(1) + ' GB';
}
setInterval(() => { if (!document.hidden && page === 'quick') refreshStats(); }, 3000);

/* ---------------------------------------------------------------- system controls */
const TOGGLES = [
  { key: 'dnd', icon: 'fa-bell-slash', title: 'Do Not Disturb', on: 'DND is active', off: 'DND is inactive', ic: ['fa-bell-slash', 'fa-bell'], need: 1 },
  { key: 'bypass', icon: 'fa-bolt', title: 'Bypass Charging Mode', on: 'Bypass is active', off: 'Bypass is inactive', ic: ['fa-bolt', 'fa-bolt'], need: 2 },
  { key: 'battery_saver', icon: 'fa-battery-quarter', title: 'Battery Saver', on: 'Battery saver is on', off: 'Battery saver is off', ic: ['fa-leaf', 'fa-leaf'], need: 1 },
  { key: 'hi_refresh', icon: 'fa-gauge-high', title: 'Max Refresh Rate', on: 'Max refresh locked', off: 'Refresh rate is auto', ic: ['fa-display', 'fa-display'], need: 1 },
  { key: 'fast_anim', icon: 'fa-wand-magic-sparkles', title: 'Fast Animations', on: 'Animations 0.5x', off: 'Animations 1x', ic: ['fa-forward-fast', 'fa-forward'], need: 1 },
  { key: 'stay_awake', icon: 'fa-plug-circle-bolt', title: 'Stay Awake (Charging)', on: 'Screen stays on', off: 'Normal screen timeout', ic: ['fa-sun', 'fa-moon'], need: 1 }
];
let tState = {};
const tl = $('#toggle-list');
TOGGLES.forEach(t => {
  const d = document.createElement('div');
  d.className = 'sys'; d.id = 'sys-' + t.key;
  d.innerHTML = '<h3><i class="fas ' + t.icon + '"></i>' + t.title + (t.need === 2 ? ' <span class="badge">ROOT</span>' : '') + '</h3>' +
    '<div class="row"><div class="state"><i class="fas ' + t.ic[1] + '"></i><span>--</span></div><label class="switch"><input type="checkbox"><span></span></label></div><div class="need" hidden></div>';
  tl.appendChild(d);
  const inp = $('input', d);
  inp.addEventListener('change', async () => {
    const want = inp.checked;
    if (rank() < t.need) { inp.checked = !want; toast(t.need === 2 ? 'Root required for this control' : 'Enable Shizuku or Root first (HOME \u2192 Access Mode)', 'error'); return; }
    haptic(); inp.disabled = true;
    const r = await call('toggle_set', { key: t.key, on: want });
    inp.disabled = false;
    const label = t.title.split(' (')[0].toUpperCase();
    term(r.ok ? label + (want ? ' enabled' : ' disabled') : label + ' failed: ' + (r.msg || 'error'), r.ok ? '' : 'error');
    if (!r.ok) toast(r.msg || 'Failed', 'error');
    refreshToggles();
  });
});
function renderToggle(t) {
  const d = $('#sys-' + t.key); if (!d) return;
  const st = tState[t.key]; const on = !!(st && st.on); const sup = !st || st.supported !== false;
  d.classList.toggle('on', on);
  $('.state i', d).className = 'fas ' + t.ic[on ? 0 : 1];
  $('.state span', d).textContent = sup ? (on ? t.on : t.off) : 'Not supported on this device';
  const inp = $('input', d); inp.checked = on; inp.disabled = !sup;
  const need = $('.need', d);
  const locked = rank() < t.need;
  d.classList.toggle('locked', locked);
  need.hidden = !locked;
  need.textContent = locked ? (t.need === 2 ? 'Needs Root access' : 'Needs Shizuku or Root') : '';
}
const lockToggles = () => TOGGLES.forEach(renderToggle);
async function refreshToggles() {
  const r = await call('toggle_get_all');
  if (r && r.data) { tState = r.data; lockToggles(); }
}
setInterval(() => { if (!document.hidden && page === 'adv') refreshToggles(); }, 6000);

/* governor */
async function refreshGov() {
  const hint = $('#gov-hint'), chips = $('#gov-chips');
  if (rank() < 2) { hint.innerHTML = 'CPU governor control needs <b>Root</b>.'; chips.innerHTML = ''; return; }
  const r = await call('gov_info');
  if (!r.ok || !r.data) { hint.textContent = r.msg || 'Governor info unavailable'; chips.innerHTML = ''; return; }
  hint.innerHTML = 'Current: <b>' + r.data.current + '</b>';
  chips.innerHTML = '';
  (r.data.available || []).forEach(g => {
    const c = document.createElement('button');
    c.className = 'chip' + (g === r.data.current ? ' on' : ''); c.textContent = g;
    c.addEventListener('click', async () => {
      haptic(); const x = await call('gov_set', { name: g });
      term(x.ok ? 'GOVERNOR set to ' + g : 'GOVERNOR failed: ' + (x.msg || 'error'), x.ok ? '' : 'error');
      refreshGov();
    });
    chips.appendChild(c);
  });
}

/* ---------------------------------------------------------------- settings */
const THEMES = [['#00f5d4', '#9d4edd'], ['#ff4dd2', '#7b2cff'], ['#39ff14', '#00b4d8'], ['#ffb300', '#ff3b3b']];
const th = $('#themes');
function applyTheme(i) {
  const [a, b] = THEMES[i] || THEMES[0];
  document.documentElement.style.setProperty('--accent', a);
  document.documentElement.style.setProperty('--accent2', b);
  $$('.tdot').forEach((d, k) => d.classList.toggle('on', k === i));
}
THEMES.forEach((t, i) => {
  const d = document.createElement('button'); d.className = 'tdot'; d.style.setProperty('--tc', t[0]);
  d.addEventListener('click', () => { store.set('theme', i); applyTheme(i); haptic(); });
  th.appendChild(d);
});
applyTheme(store.get('theme', 0));
$('#set-rain').checked = store.get('rain', true);
$('#set-haptic').checked = store.get('haptic', true);
$('#set-rain').addEventListener('change', e => { store.set('rain', e.target.checked); rainOn = e.target.checked; $('#rain').style.display = rainOn ? '' : 'none'; });
$('#set-haptic').addEventListener('change', e => store.set('haptic', e.target.checked));
$('#set-boot').addEventListener('change', async e => {
  const r = await call('boot_set', { on: e.target.checked });
  if (!r.ok) { e.target.checked = !e.target.checked; toast(r.msg || 'Failed', 'error'); }
});

/* ---------------------------------------------------------------- matrix rain */
let rainOn = store.get('rain', true);
(function rain() {
  const c = $('#rain'), x = c.getContext('2d'); let cols, drops;
  function size() { c.width = innerWidth; c.height = innerHeight; cols = Math.floor(c.width / 14); drops = Array.from({ length: cols }, () => Math.random() * -50); }
  size(); addEventListener('resize', size);
  if (!rainOn) c.style.display = 'none';
  setInterval(() => {
    if (!rainOn || document.hidden) return;
    x.fillStyle = 'rgba(4,5,13,.12)'; x.fillRect(0, 0, c.width, c.height);
    x.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#0f8'; x.font = '13px monospace';
    for (let i = 0; i < cols; i++) {
      x.fillText(Math.random() > .5 ? '1' : '0', i * 14, drops[i] * 14);
      if (drops[i] * 14 > c.height && Math.random() > .975) drops[i] = 0;
      drops[i]++;
    }
  }, 60);
})();

/* ---------------------------------------------------------------- boot */
async function refreshStatus() {
  const raw = native('getStatus'); if (raw) { try { applyStatus(JSON.parse(raw)); } catch (e) {} }
}
setInterval(() => { if (!document.hidden && page === 'home') refreshStatus(); }, 4000);
window.addEventListener('load', () => {
  refreshStatus(); refreshStats(); placeIndicator();
  log('KayrootEngine initialized successfully', 'success');
  setTimeout(() => $('#loading').classList.add('hide'), 900);
});

/* ---------------------------------------------------------------- mock (browser preview only) */
function installMock() {
  const s = { mode: 'shizuku', shizukuInstalled: true, shizukuRunning: true, shizukuGranted: true, sdk: 34, device: 'Preview Phone', soc: 'Snapdragon', profile: 'daytoday', boot: false };
  const t = { dnd: { on: false }, bypass: { on: true, supported: true }, battery_saver: { on: false }, hi_refresh: { on: true }, fast_anim: { on: false }, stay_awake: { on: false } };
  window.KayrootApp = {
    getStatus: () => JSON.stringify(s),
    getStats: () => JSON.stringify({ battery: { level: 62, temp: 36.4, charging: false, voltage: 4012 }, ram: { usedMb: 4210, totalMb: 7600, pct: 55 }, storage: { freeGb: 88.2, totalGb: 256, pct: 66 } }),
    selectMode: m => { s.mode = m; window.onKayrootStatus(s); },
    openShizuku() {}, haptic() {},
    call: (a, args, cb) => setTimeout(() => {
      const A = JSON.parse(args); let r = { ok: true, msg: '' };
      if (a === 'toggle_get_all') r.data = t;
      else if (a === 'toggle_set') { t[A.key].on = A.on; }
      else if (a === 'gov_info') r.data = { current: 'schedutil', available: ['performance', 'schedutil', 'powersave', 'conservative'] };
      else if (a === 'profile') s.profile = A.name;
      window[cb](r);
    }, 400)
  };
}
})();
