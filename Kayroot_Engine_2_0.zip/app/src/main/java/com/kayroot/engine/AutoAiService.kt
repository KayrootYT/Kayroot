package com.kayroot.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Auto AI Mode: every few seconds looks at battery temperature, charge level and the foreground app,
 * then switches between the Game / Multitasking / Power Saving profiles.
 * Needs Shizuku or Root (to read the foreground app and to apply profiles).
 */
class AutoAiService : Service() {

    companion object {
        private const val CHANNEL = "kayroot_ai"
        @Volatile var current: String = ""
        @Volatile var reason: String = ""

        fun start(ctx: Context) {
            val i = Intent(ctx, AutoAiService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AutoAiService::class.java))
            current = ""; reason = ""
        }

        private val KNOWN_GAMES = listOf(
            "pubg", "tencent.ig", "activision", "supercell", "mobilelegends", "moonton", "garena", "freefire",
            "roblox", "mihoyo", "genshin", "epicgames", "krafton", "bgmi", "riotgames", "netease", "nianticlabs"
        )
    }

    @Volatile private var alive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences("kayroot", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("ai_on", false)) { stopSelf(); return START_NOT_STICKY }
        goForeground()
        if (!alive) {
            alive = true
            Thread { loop() }.apply { isDaemon = true; start() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        alive = false
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Auto AI Mode", NotificationManager.IMPORTANCE_LOW))
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Kayroot Auto AI Mode")
            .setContentText("Watching usage and switching profiles automatically")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun loop() {
        val access = AccessManager(this)
        val tweaks = Tweaks(this, access)
        val prefs = getSharedPreferences("kayroot", Context.MODE_PRIVATE)
        var applied = ""
        var thermal = false
        while (alive) {
            try {
                if (!prefs.getBoolean("ai_on", false)) break
                if (access.mode == Mode.BASIC) {
                    reason = "Needs Shizuku or Root"
                } else {
                    val b = readBattery(this)
                    thermal = if (thermal) b.temp >= 42.0 else b.temp >= 46.0
                    val fg = foregroundPackage(access)
                    val (target, why) = when {
                        thermal -> "powersave" to "High temperature (${"%.1f".format(b.temp)}\u00b0C)"
                        fg.isNotEmpty() && isGame(fg) && b.level > 10 -> "game" to "Game detected"
                        b.level <= 20 && !b.charging -> "powersave" to "Low battery (${b.level}%)"
                        else -> "daytoday" to "Balanced usage"
                    }
                    if (target != applied) {
                        if (tweaks.profile(target).errno == 0) { applied = target; current = target; reason = why }
                        else reason = "Could not apply $target"
                    } else {
                        reason = why
                    }
                }
            } catch (_: Exception) {
            }
            try { Thread.sleep(6000) } catch (_: InterruptedException) { break }
        }
        alive = false
        stopSelf()
    }

    private fun foregroundPackage(access: AccessManager): String {
        val r = access.execScript(
            "dumpsys activity activities | grep -m1 -E 'topResumedActivity|mResumedActivity'", 15_000
        )
        return Regex("u\\d+ ([\\w.]+)/").find(r.out)?.groupValues?.get(1).orEmpty()
    }

    @Suppress("DEPRECATION")
    private fun isGame(pkg: String): Boolean {
        if (KNOWN_GAMES.any { pkg.contains(it) }) return true
        return try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
        } catch (e: Exception) { false }
    }
}
