package com.kayroot.engine

import android.content.Context
import org.json.JSONObject

/** Single entry point for everything the WebUI asks for: KayrootApp.call(action, argsJson, callback). */
class Api(
    private val ctx: Context,
    private val access: AccessManager,
    private val tweaks: Tweaks,
    private val features: Features
) {
    private val prefs = ctx.getSharedPreferences("kayroot", Context.MODE_PRIVATE)

    fun status(): JSONObject = JSONObject(access.statusJson()).apply {
        put("profile", prefs.getString("ui_profile", "") ?: "")
        put("ai", JSONObject().put("on", prefs.getBoolean("ai_on", false))
            .put("profile", AutoAiService.current).put("reason", AutoAiService.reason))
        put("boot", prefs.getBoolean("boot_apply", true))
    }

    fun handle(action: String, a: JSONObject): JSONObject = when (action) {
        "profile" -> profile(a.optString("name"))
        "reset" -> {
            stopAi()
            val r = tweaks.reset()
            if (r.errno == 0) prefs.edit().putString("ui_profile", "").apply()
            res(r, "Profiles reset")
        }
        "clean" -> res(tweaks.clean(), "Cleaner finished")
        "cool" -> res(tweaks.cool(), "Cooling finished")
        "optimize" -> res(tweaks.optimize(), "Optimizer started")
        "netrefresh" -> res(tweaks.netRefresh(), "Network refreshed")
        "toggle_get_all" -> JSONObject().put("ok", true).put("data", features.toggleGetAll())
        "toggle_set" -> res(features.toggleSet(a.optString("key"), a.optBoolean("on")))
        "gov_info" -> features.govInfo()
        "gov_set" -> {
            val r = tweaks.setGovernor(a.optString("name"))
            if (r.errno == 0) {
                when (prefs.getString("ui_profile", "")) {
                    "powersave" -> tweaks.saveGovernorPref("governor_powersave", a.optString("name"))
                    "game", "auto" -> {}
                    else -> tweaks.saveGovernorPref("governor_daytoday", a.optString("name"))
                }
            }
            res(r)
        }
        "boot_set" -> {
            prefs.edit().putBoolean("boot_apply", a.optBoolean("on")).apply()
            JSONObject().put("ok", true).put("msg", "")
        }
        else -> JSONObject().put("ok", false).put("msg", "Unknown action")
    }

    private fun profile(name: String): JSONObject {
        if (name == "auto") {
            if (access.mode == Mode.BASIC) return fail("Auto AI needs Shizuku or Root. Enable it in Access Mode.")
            prefs.edit().putBoolean("ai_on", true).putString("ui_profile", "auto").apply()
            AutoAiService.start(ctx)
            return JSONObject().put("ok", true).put("msg", "")
        }
        stopAi()
        val r = tweaks.profile(name)
        if (r.errno == 0) prefs.edit().putString("ui_profile", name).apply()
        return res(r)
    }

    private fun stopAi() {
        if (prefs.getBoolean("ai_on", false)) {
            prefs.edit().putBoolean("ai_on", false).apply()
            AutoAiService.stop(ctx)
        }
    }

    private fun fail(msg: String) = JSONObject().put("ok", false).put("msg", msg)

    private fun res(r: ExecResult, okMsg: String = ""): JSONObject {
        val line = r.out.lineSequence()
            .firstOrNull { it.startsWith("ok: background") || it.startsWith("ok: app caches") }
            ?.removePrefix("ok: ")
        return JSONObject().put("ok", r.errno == 0)
            .put("msg", if (r.errno == 0) (line ?: okMsg) else r.err.trim().ifEmpty { "Failed" })
    }
}
