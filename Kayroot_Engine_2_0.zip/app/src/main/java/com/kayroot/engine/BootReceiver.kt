package com.kayroot.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-applies the last profile after boot (only possible in Root mode; Shizuku does not auto-start). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("kayroot", Context.MODE_PRIVATE)
        val last = prefs.getString("last_profile", null) ?: return
        val access = AccessManager(context)
        if (access.mode != Mode.ROOT) return
        val pending = goAsync()
        Thread {
            try {
                Thread.sleep(15_000) // let the system settle, like service.sh did
                Tweaks(context, access).profile(last)
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }.start()
    }
}
