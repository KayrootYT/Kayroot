package com.kayroot.engine

/**
 * The original WebUI (core.js) sends commands like  `su -c Kroot --game`.
 * Instead of executing arbitrary strings, we ALLOW-LIST exactly those commands and map them to [Tweaks].
 */
class CommandRouter(private val tweaks: Tweaks) {

    private val writeRe = Regex("^su -c \"echo '([A-Za-z0-9_-]*)' > (/\\S+)\"$")
    private val catRe = Regex("^su -c cat (/sys/\\S+)$")

    fun handle(cmd: String): ExecResult {
        val c = cmd.trim()
        return when (c) {
            "su -c Kroot --game" -> tweaks.profile("game")
            "su -c Kroot --daytoday" -> tweaks.profile("daytoday")
            "su -c Kroot --powersave" -> tweaks.profile("powersave")
            "su -c Kroot --reset" -> tweaks.reset()
            "su -c Quick --cool" -> tweaks.cool()
            "su -c Quick --clear" -> tweaks.clean()
            "su -c Quick --optimize" -> tweaks.optimize()
            else -> other(c)
        }
    }

    private fun other(c: String): ExecResult {
        catRe.matchEntire(c)?.let { return tweaks.readSysfs(it.groupValues[1]) }
        writeRe.matchEntire(c)?.let {
            val value = it.groupValues[1]
            val path = it.groupValues[2]
            return when {
                path.startsWith("/data/KayrootEngine/") ->
                    tweaks.saveGovernorPref(path.removePrefix("/data/KayrootEngine/"), value)
                Regex("^/sys/devices/system/cpu/cpu\\d+/cpufreq/scaling_governor$").matches(path) ->
                    tweaks.setGovernor(value)
                else -> ExecResult(126, "", "Path not allowed")
            }
        }
        return ExecResult(127, "", "Unsupported command")
    }
}
