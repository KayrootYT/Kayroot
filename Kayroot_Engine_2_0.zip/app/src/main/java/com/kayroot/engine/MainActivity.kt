package com.kayroot.engine

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var access: AccessManager
    private lateinit var tweaks: Tweaks
    private lateinit var router: CommandRouter
    private val io = Executors.newSingleThreadExecutor()

    private val binderReceived = Shizuku.OnBinderReceivedListener { pushStatus() }
    private val binderDead = Shizuku.OnBinderDeadListener { pushStatus() }
    private val permResult = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) {
            access.mode = Mode.SHIZUKU
            io.execute { access.execScript("echo warmup") } // bind the user service early
            toast("Shizuku connected - Pro features unlocked", "success")
        } else {
            toast("Shizuku permission denied", "error")
        }
        pushStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        access = AccessManager(this)
        tweaks = Tweaks(this, access)
        router = CommandRouter(tweaks)

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.isLongClickable = false
        web.isHapticFeedbackEnabled = false
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true       // localStorage (profile selection) is used by core.js
            allowFileAccess = true         // assets only
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = true
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.scheme == "file") return false
                openExternal(u.toString())   // t.me, upi://..., https links
                return true
            }

            override fun onPageFinished(view: WebView, url: String) = pushStatus()
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }
        // "ksu" keeps the original core.js working unchanged: ksu.exec(cmd, optionsJson, callbackName)
        web.addJavascriptInterface(ExecBridge(), "ksu")
        web.addJavascriptInterface(AppApi(), "KayrootApp")
        setContentView(web)
        web.loadUrl("file:///android_asset/webroot/index.html")

        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceived)
            Shizuku.addBinderDeadListener(binderDead)
            Shizuku.addRequestPermissionResultListener(permResult)
        } catch (_: Throwable) {}

        io.execute { tweaks.restoreGovernor() }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) pushStatus()
    }

    override fun onDestroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceived)
            Shizuku.removeBinderDeadListener(binderDead)
            Shizuku.removeRequestPermissionResultListener(permResult)
        } catch (_: Throwable) {}
        web.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ helpers
    private fun js(code: String) = web.post { web.evaluateJavascript(code, null) }

    private fun pushStatus() {
        io.execute {
            val json = access.statusJson()
            js("window.onKayrootStatus && window.onKayrootStatus($json)")
        }
    }

    private fun toast(msg: String, type: String) =
        js("typeof showNotification==='function' && showNotification(${JSONObject.quote(msg)},'$type')")

    private fun openExternal(url: String) = runOnUiThread {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (_: Exception) { toast("No app found to open this link", "error") }
    }

    // ------------------------------------------------------------------ JS bridges
    inner class ExecBridge {
        @JavascriptInterface
        fun exec(cmd: String, options: String, callback: String) {
            io.execute {
                val r = try { router.handle(cmd) } catch (e: Exception) { ExecResult(1, "", e.message ?: "error") }
                val cb = callback.filter { it.isLetterOrDigit() || it == '_' }
                js("window['$cb'] && window['$cb'](${r.errno}, ${JSONObject.quote(r.out)}, ${JSONObject.quote(r.err)})")
            }
        }
    }

    inner class AppApi {
        @JavascriptInterface
        fun getStatus(): String = access.statusJson()

        @JavascriptInterface
        fun selectMode(m: String) {
            when (m) {
                "basic" -> { access.mode = Mode.BASIC; toast("Basic mode active", "info"); pushStatus() }
                "shizuku" -> selectShizuku()
                "root" -> io.execute {
                    toast("Checking root access...", "info")
                    if (access.checkRoot()) {
                        access.mode = Mode.ROOT
                        toast("Root access granted - full features unlocked", "success")
                    } else {
                        toast("Root not available on this device", "error")
                    }
                    pushStatus()
                }
            }
        }
    }

    private fun selectShizuku() {
        if (!access.shizukuInstalled()) {
            toast("Shizuku is not installed. Opening download page...", "error")
            openExternal("https://github.com/RikkaApps/Shizuku/releases")
            return
        }
        if (!access.shizukuRunning()) {
            toast("Start Shizuku first (Wireless debugging), then tap Shizuku again", "error")
            packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let {
                runOnUiThread { startActivity(it) }
            }
            return
        }
        if (access.shizukuGranted()) {
            access.mode = Mode.SHIZUKU
            io.execute { access.execScript("echo warmup") }
            toast("Shizuku connected - Pro features unlocked", "success")
            pushStatus()
        } else {
            runOnUiThread {
                try { Shizuku.requestPermission(100) } catch (e: Throwable) { toast("Shizuku error: ${e.message}", "error") }
            }
        }
    }
}
