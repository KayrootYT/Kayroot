# Multitasking (Shizuku level)
ok cmd power set-fixed-performance-mode-enabled false
undo_powersave
