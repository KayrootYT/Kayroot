# PowerSaving (root): lowest-power governor
G=$(pick_gov "$GOV_POWER" powersave conservative schedutil)
[ -n "$G" ] && setgov "$G"
