t() { [ -r "$2" ] && echo "$1=1" || echo "$1=0"; }
t procstat /proc/stat
t cpufreq /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq
t gpu_kgsl /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage
t thermal /sys/class/thermal/thermal_zone0/temp
dumpsys SurfaceFlinger --list >/dev/null 2>&1 && echo sf=1 || echo sf=0
cmd package list packages -d >/dev/null 2>&1 && echo pm=1 || echo pm=0
cmd package 2>&1 | grep -q 'compile' && echo dexopt=1 || echo dexopt=0
command -v fstrim >/dev/null 2>&1 && echo fstrim=1 || echo fstrim=0
sm help 2>&1 | grep -q 'fstrim' && echo smtrim=1 || echo smtrim=0
B=0
for p in /sys/class/power_supply/battery/input_suspend /sys/class/qcom-battery/input_suspend /sys/class/power_supply/battery/charge_disable /sys/class/power_supply/battery/batt_slate_mode /sys/class/power_supply/battery/charging_enabled /sys/class/power_supply/battery/battery_charging_enabled; do
  [ -e "$p" ] && B=1
done
echo bypass=$B
