# Safe Shizuku cooling helper. Android/OEM thermal management remains in control.
# Do not force-stop every background app: this can interrupt navigation, messaging, music and uploads.
echo "info: Android thermal management remains enabled; no apps were force-stopped"
