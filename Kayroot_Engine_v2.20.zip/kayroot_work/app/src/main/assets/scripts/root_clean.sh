# Conservative cleaner (root). Does not erase crash diagnostics, user downloads, photos, or documents.
sync
for d in /data/user/*/*/cache /data/user_de/*/*/cache; do
  [ -d "$d" ] || continue
  find "$d" -mindepth 1 -maxdepth 1 -exec rm -rf {} + 2>/dev/null
done
echo "ok: app cache cleanup attempted; diagnostic logs and user files preserved"
