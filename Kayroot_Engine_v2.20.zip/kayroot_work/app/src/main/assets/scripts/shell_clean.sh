# Conservative Shizuku cleaner: request Android cache trimming only. Never delete user Download files.
ok pm trim-caches 2G
echo "info: user files and diagnostic logs were preserved"
