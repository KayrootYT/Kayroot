# Reset profiles (Shizuku level)
ok cmd power set-fixed-performance-mode-enabled false
undo_powersave
echo "ok: profiles reset"
