# Use Android's supported background dex optimization job; avoid force-compiling every app or killing all apps.
ok cmd package bg-dexopt-job
echo "info: Android will schedule supported app optimization when appropriate"
