# Net Refresh (Shizuku level): cycle airplane mode, fall back to a mobile-data cycle
if cmd connectivity airplane-mode enable >/dev/null 2>&1; then
  sleep 2
  cmd connectivity airplane-mode disable >/dev/null 2>&1
  echo "ok: airplane mode cycled"
else
  svc data disable >/dev/null 2>&1
  sleep 1
  svc data enable >/dev/null 2>&1 && echo "ok: mobile data cycled"
fi
