package com.kayroot.engine

import android.content.Context
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

/** Quick Settings tile: toggles Auto AI (adaptive rules engine). Needs Shizuku or Root like the in-app switch. */
class AiTile : TileService() {

    private fun prefs() = getSharedPreferences("kayroot", Context.MODE_PRIVATE)

    override fun onStartListening() { refresh() }

    override fun onClick() {
        if (AccessManager(this).mode == Mode.BASIC) {
            Toast.makeText(this, "Auto AI needs Shizuku or Root", Toast.LENGTH_SHORT).show()
            return
        }
        val on = !prefs().getBoolean("ai_on", false)
        prefs().edit().putBoolean("ai_on", on).putString("ui_profile", if (on) "auto" else "").apply()
        if (on) AutoAiService.start(this) else AutoAiService.stop(this)
        OpLog.add(this, if (on) "Auto AI started from tile" else "Auto AI stopped from tile")
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.label = "Kayroot AI"
        t.state = if (prefs().getBoolean("ai_on", false)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.updateTile()
    }
}
