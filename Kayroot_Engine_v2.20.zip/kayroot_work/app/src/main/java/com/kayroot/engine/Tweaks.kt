package com.kayroot.engine

import android.app.ActivityManager
import android.content.Context
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * The "engine": replaces the Kroot / Quick native binaries of the Magisk module.
 * Every tweak is a plain shell script in assets/scripts/ so it is easy to read and edit.
 */
class Tweaks(private val ctx: Context, private val access: AccessManager) {

    private val prefs = ctx.getSharedPreferences("kayroot", Context.MODE_PRIVATE)
    private val scheduler = Executors.newSingleThreadScheduledExecutor()

    private fun asset(name: String): String =
        ctx.assets.open("scripts/$name").bufferedReader().use { it.readText() }

    private fun safe(s: String) = s.filter { it.isLetterOrDigit() || it == '_' || it == '-' }

    private fun header(): String {
        val day = safe(prefs.getString("gov_daytoday", "schedutil") ?: "schedutil")
        val pow = safe(prefs.getString("gov_powersave", "powersave") ?: "powersave")
        val prev = safe(prefs.getString("last_profile", "") ?: "")
        return "GOV_DAY='$day'\nGOV_POWER='$pow'\nPREV_PROFILE='$prev'\n" + asset("common.sh") + "\n"
    }

    private fun finalize(r: ExecResult): ExecResult {
        val applied = r.out.lineSequence().count { it.startsWith("ok:") }
        if (applied > 0) return ExecResult(0, r.out, r.err)
        val msg = r.err.trim().ifEmpty { "Nothing could be applied on this device in ${access.mode.name.lowercase()} mode." }
        return ExecResult(if (r.errno == 0) 1 else r.errno, r.out, msg)
    }

    private fun runTweak(shellAsset: String, rootAsset: String?, basic: (() -> ExecResult)?): ExecResult {
        val m = access.mode
        if (m == Mode.BASIC) {
            return basic?.invoke()
                ?: ExecResult(2, "", "Basic mode can't do this. Enable Shizuku or Root in Access Mode.")
        }
        var script = header() + asset(shellAsset)
        if (m == Mode.ROOT && rootAsset != null) script += "\n" + asset(rootAsset)
        return finalize(access.execScript(script))
    }

    // ------------------------------------------------------------------ Profiles
    fun profile(name: String): ExecResult {
        val (shellAsset, rootAsset) = when (name) {
            "game" -> "shell_game.sh" to "root_game.sh"
            "daytoday" -> "shell_daytoday.sh" to "root_daytoday.sh"
            "powersave" -> "shell_powersave.sh" to "root_powersave.sh"
            else -> return ExecResult(127, "", "Unknown profile")
        }
        val r = runTweak(shellAsset, rootAsset, null)
        if (r.errno == 0) prefs.edit().putString("last_profile", name).apply()
        return r
    }

    fun reset(): ExecResult {
        val r = runTweak("shell_reset.sh", "root_reset.sh", null)
        prefs.edit().remove("last_profile").apply()
        return r
    }

    // ------------------------------------------------------------------ Quick menu
    fun clean(): ExecResult = runTweak("shell_clean.sh", "root_clean.sh") { killBackground() }

    fun optimize(): ExecResult = runTweak("shell_optimize.sh", "root_optimize.sh", null)

    fun cool(): ExecResult {
        val r = runTweak("shell_cool.sh", "root_cool.sh") { killBackground() }
        if (access.mode == Mode.ROOT && r.errno == 0) {
            val prev = r.out.lineSequence().firstOrNull { it.startsWith("prev_gov=") }
                ?.removePrefix("prev_gov=")?.trim().orEmpty()
            if (prev.isNotEmpty() && prev != "powersave" && prev != "conservative") {
                // keep the very first governor if cooling is triggered twice
                val keep = prefs.getString("cool_prev", null) ?: prev
                prefs.edit().putString("cool_prev", keep).apply()
                scheduler.schedule({ restoreGovernor() }, 30, TimeUnit.SECONDS)
            }
        }
        return r
    }

    /** Called after the 30s cooling window and once at app start (in case the app was killed meanwhile). */
    fun restoreGovernor() {
        val prev = prefs.getString("cool_prev", null) ?: return
        if (access.mode == Mode.ROOT) {
            access.execScript(header() + "setgov '${safe(prev)}'")
        }
        prefs.edit().remove("cool_prev").apply()
    }

    fun netRefresh(): ExecResult = runTweak("shell_netrefresh.sh", null, null)

    /** Runs an ad-hoc script body (with the common helpers) in the current mode. Needs Shizuku or Root. */
    fun runRaw(body: String): ExecResult {
        if (access.mode == Mode.BASIC) return ExecResult(2, "", "Enable Shizuku or Root first (HOME > Access Mode)")
        return finalize(access.execScript(header() + body))
    }

    // ------------------------------------------------------------------ CPU governor (root only)
    fun setGovernor(g: String): ExecResult {
        if (access.mode != Mode.ROOT) return ExecResult(1, "", "CPU governor control needs Root")
        val r = access.execScript(header() + "setgov '${safe(g)}'")
        return finalize(r)
    }

    fun saveGovernorPref(which: String, value: String): ExecResult {
        val key = when (which) { "governor_daytoday" -> "gov_daytoday"; "governor_powersave" -> "gov_powersave"; else -> return ExecResult(127, "", "bad key") }
        prefs.edit().putString(key, safe(value)).apply()
        return ExecResult(0, "saved", "")
    }

    fun readSysfs(path: String): ExecResult {
        // allow-listed read-only access
        if (!Regex("^/sys/devices/system/cpu/cpu\\d+/cpufreq/(scaling_available_governors|scaling_governor)$").matches(path)) {
            return ExecResult(126, "", "Path not allowed")
        }
        val r = access.execScript("cat $path")
        return if (r.errno == 0 && r.out.isNotBlank()) r else ExecResult(1, "", r.err.ifEmpty { "unreadable" })
    }

    // ------------------------------------------------------------------ Basic (no privileges) fallback
    private fun killBackground(): ExecResult {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        var n = 0
        val excl = HashSet<String>()
        try {
            val arr = org.json.JSONArray(prefs.getString("excl", "[]"))
            for (i in 0 until arr.length()) excl.add(arr.optString(i))
        } catch (_: Exception) {}
        for (ai in ctx.packageManager.getInstalledApplications(0)) {
            if (ai.packageName == ctx.packageName || ai.packageName in excl) continue
            try { am.killBackgroundProcesses(ai.packageName); n++ } catch (_: Exception) {}
        }
        val skip = setOf("WebView", "org.chromium.android_webview")
        ctx.cacheDir.listFiles()?.filter { it.name !in skip }?.forEach { it.deleteRecursively() }
        return ExecResult(0, "ok: background processes closed for $n apps", "")
    }
}
