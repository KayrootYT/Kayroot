package com.kayroot.engine

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

enum class Mode { BASIC, SHIZUKU, ROOT }

/**
 * Decides HOW a shell script is executed:
 *  - BASIC   -> app uid (very limited)
 *  - SHIZUKU -> shell uid via Shizuku user service (no root)
 *  - ROOT    -> su
 */
class AccessManager(context: Context) {

    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("kayroot", Context.MODE_PRIVATE)

    @Volatile private var service: IShellService? = null
    @Volatile private var bindLatch: CountDownLatch? = null
    @Volatile var rootChecked = false
    @Volatile var rootOk = false

    var mode: Mode
        get() = try { Mode.valueOf(prefs.getString("mode", Mode.BASIC.name)!!) } catch (e: Exception) { Mode.BASIC }
        set(v) { prefs.edit().putString("mode", v.name).apply() }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            service = IShellService.Stub.asInterface(binder)
            bindLatch?.countDown()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
        }
    }

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("shell")
            .debuggable(false)
            .version(BuildConfig.VERSION_CODE)
    }

    // ---------------- Shizuku state ----------------
    fun shizukuInstalled(): Boolean = try {
        ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
    } catch (e: Exception) { false }

    fun shizukuRunning(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun shizukuGranted(): Boolean = try {
        shizukuRunning() && !Shizuku.isPreV11() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    @Synchronized
    private fun ensureService(): IShellService? {
        service?.let { if (it.asBinder().pingBinder()) return it }
        if (!shizukuGranted()) return null
        val latch = CountDownLatch(1)
        bindLatch = latch
        try {
            Shizuku.bindUserService(userServiceArgs, connection)
        } catch (e: Throwable) {
            return null
        }
        latch.await(10, TimeUnit.SECONDS)
        return service
    }

    // ---------------- Root state ----------------
    fun checkRoot(): Boolean {
        val r = Shell.run(arrayOf("su", "-c", "id"), 20_000)
        rootOk = r[0] == "0" && r[1].contains("uid=0")
        rootChecked = true
        return rootOk
    }

    // ---------------- Execution ----------------
    fun execScript(script: String, timeoutMs: Long = 90_000): ExecResult = when (mode) {
        Mode.ROOT -> Shell.toResult(Shell.run(arrayOf("su", "-c", script), timeoutMs))
        Mode.SHIZUKU -> {
            val s = ensureService()
            if (s == null) {
                ExecResult(1, "", "Shizuku is not running or permission is not granted. Open Access Mode and pick Shizuku.")
            } else try {
                Shell.toResult(s.exec(script, timeoutMs))
            } catch (e: Exception) {
                ExecResult(1, "", e.message ?: "Shizuku error")
            }
        }
        Mode.BASIC -> Shell.toResult(Shell.run(arrayOf("sh", "-c", script), timeoutMs))
    }

    fun statusJson(): String = JSONObject().apply {
        put("mode", mode.name.lowercase())
        put("shizukuInstalled", shizukuInstalled())
        put("shizukuRunning", shizukuRunning())
        put("shizukuGranted", shizukuGranted())
        put("rootChecked", rootChecked)
        put("rootOk", rootOk)
        put("sdk", Build.VERSION.SDK_INT)
        put("device", DeviceInfo.device)
        put("soc", DeviceInfo.soc)
    }.toString()
}
