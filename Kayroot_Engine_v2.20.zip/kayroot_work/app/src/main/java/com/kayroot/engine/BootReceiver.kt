package com.kayroot.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** After boot: restart Auto AI, or re-apply the last profile (profiles via sysfs need Root). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences("kayroot", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("boot_apply", true)) return
        val access = AccessManager(context)
        if (access.mode == Mode.BASIC) return
        if (prefs.getBoolean("ai_on", false)) {
            try { AutoAiService.start(context) } catch (_: Exception) {}
            return
        }
        val last = prefs.getString("last_profile", null) ?: return
        if (access.mode != Mode.ROOT) return
        val pending = goAsync()
        Thread {
            try {
                Thread.sleep(15_000) // let the system settle, like service.sh did
                Tweaks(context, access).profile(last)
            } catch (_: Exception) {
            } finally {
                pending.finish()
            }
        }.start()
    }
}
