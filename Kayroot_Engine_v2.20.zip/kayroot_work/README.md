# Kayroot Engine – Android App (Non-Root + Shizuku + Root)

Magisk module **Kayroot Engine 2.0** ka same UI + animations, ab ek normal APK ke roop me.
WebUI (`app/src/main/assets/webroot`) original hai; backend Kotlin me likha gaya hai.

## APK kaise banaye (GitHub)
1. Naya GitHub repo banao aur is poore folder ka content push karo (`main` branch).
2. **Actions** tab -> *Build APK* khud chalega (ya *Run workflow* dabao).
3. Build khatam hone par run ke **Artifacts** se `KayrootEngine-apk` download karo -> `KayrootEngine-v2.0.apk`.
4. Release banana ho to tag push karo: `git tag v2.0 && git push --tags` (APK Releases me aa jayega).

**Signing (optional but recommended):** Repo Settings -> Secrets me `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`,
`KEY_ALIAS`, `KEY_PASSWORD` daal do, taaki har update same signature se bane. Secrets na ho to
CI temporary key bana leta hai (APK install hoga, par update ke liye uninstall karna pad sakta hai).

Local build: Android Studio me folder open karo, ya `gradle :app:assembleRelease` (JDK 17, Gradle 8.9).

## Tabs aur features (v2.1)
| Tab | Features |
|---|---|
| HOME | Access Mode (Basic / Shizuku / Root), Profile Manager: **Auto AI Mode**, Game Booster, Multitasking, Power Saving, Reset |
| QUICK | **Live Monitor** (battery, RAM, storage, temp), Cleaner, Cooling, Optimizer, **Net Refresh**, Activity Log |
| ADVANCE | **Do Not Disturb**, **Bypass Charging** (Root), Battery Saver, Max Refresh Rate, Fast Animations, Stay Awake while charging, **CPU Governor** chooser (Root), terminal log |
| ABOUT | Accent **themes**, matrix rain on/off, haptics, re-apply on boot, Shizuku guide, Support/Telegram |

**Auto AI Mode:** foreground service jo har 6 sec battery temp, charge level aur foreground app dekhta hai:
game open -> Game Booster, temp >= 46C ya battery <= 20% (not charging) -> Power Saving, baaki -> Multitasking.
Shizuku ya Root zaroori hai.


## v2.2 - kya naya hai
Bottom nav ab 6 tab: **HOME, MONITOR, APPS, QUICK, ADVANCE, SETTINGS** (ABOUT ab SETTINGS ke andar hai).

| Tab | Naya |
|---|---|
| HOME | AI Optimization Engine card (running status, mode, last decision, last optimization, Shizuku/Root status, Stop/Restart), Recent operations, Power Save / Auto / Performance / Balanced profiles |
| MONITOR | Performance Monitor (CPU %, cores, clock, GPU, temps, thermal status, RAM, memory pressure, history graph, interval, start/stop), Battery Management, FPS + stats floating overlay |
| APPS | MANAGE (search, filter, details, launch, app settings, uninstall, disable/enable, cleaner exclusion list) + DEBLOAT (review list, preview plan, confirm, per-app result, re-enable) |
| QUICK | Cleaning summary + logcat view/clear, Extra Optimization (dexopt / speed-profile / trim, daily maintenance, reset), Emergency Cooldown (+ Restore), persistent Activity Log |
| SETTINGS | Theme/haptic/boot, Permission checklist, Capability scan (Supported / Partial / Shizuku required / Root required ...), Debug toggle, Shizuku guide, About + Privacy |
| Quick Settings tile | "Kayroot AI" tile toggles Auto AI |

Full status of every requested feature: `docs/FEATURE_MATRIX.md`.

**Sach:** ye code is session me compile/test nahi hua (SDK nahi tha). GitHub Actions se build karke phone par test karna zaroori hai.

## Kaun si mode me kya chalega
| Feature | Basic | Shizuku | Root |
|---|:--:|:--:|:--:|
| Live Monitor, themes, settings | yes | yes | yes |
| Cleaner | bg apps close + own cache | sab apps ka cache trim | + `/data` caches wipe |
| Cooling | bg apps close | bg kill-all | + 30s low-power CPU governor |
| Optimizer | - | bg dexopt + speed-profile recompile | + I/O, F2FS, VM, scheduler, fstrim |
| Profiles + Auto AI | - | performance mode, battery saver | + CPU governor |
| DND, Battery Saver, Refresh Rate, Animations, Stay Awake, Net Refresh | - | yes | yes |
| Bypass Charging, CPU Governor | - | - | yes |

**Zaroori sach:** CPU governor, sysfs aur kernel tweaks ke liye root chahiye; Shizuku (ADB shell) unhe likh nahi sakta.
**Bypass Charging** kernel node par depend karta hai (`input_suspend`, `charging_enabled`, `batt_slate_mode` etc). App jo mile
use try karta hai, nahi mila to "Not supported on this device" dikhata hai. Kuch commands Android 12+ par hi hote hain.

## Shizuku use karna
1. Shizuku app install karo -> Wireless debugging se start karo.
2. Kayroot app -> **Access Mode -> Shizuku** -> permission Allow.

## Project structure
```
app/src/main/
  assets/webroot/        UI v2 (index.html, assets/ui.css, assets/app.js) - 4 tabs, same neon theme
  assets/scripts/        asli tweaks (shell_*.sh = Shizuku level, root_*.sh = root level)
  aidl/.../IShellService Shizuku user-service interface
  java/com/kayroot/engine/
    MainActivity.kt      WebView + JS bridge (window.KayrootApp)
    Api.kt               UI actions ka single entry point (allow-listed)
    Features.kt          live stats, system toggles, bypass charging, governor info
    AutoAiService.kt     Auto AI Mode (foreground service)
    Tweaks.kt            profiles, cleaner, cooling, optimizer
    AccessManager.kt     Basic / Shizuku / Root execution
    ShellService.kt      Shizuku process me chalta hai (shell uid)
    BootReceiver.kt      root mode: boot ke baad profile re-apply
    Monitor.kt           CPU/GPU/temp/RAM/battery sampling (N/A when not exposed)
    Apps.kt              app list, details, disable/enable, debloat list + protected packages
    Extras.kt            dexopt/trim, scheduling, emergency cooldown
    OverlayService.kt    floating FPS/stats overlay
    CapabilityManager.kt capability scan + permission checklist
    OpLog.kt             persistent history
    AiTile.kt / MaintenanceJob.kt  QS tile, daily maintenance job
```

## Notes
* Original `Kroot` / `Quick` binaries packed/encrypted hain, unka code padha nahi ja sakta. Unke features UI + `service.sh`
  ke hisaab se naye scripts me **re-implement** kiye gaye hain (behaviour bilkul identical hone ki guarantee nahi).
* `service.sh` ke risky hisse (logd/statsd stop, `/data/local/tmp` & `/cache` wipe, dalvik-cache delete) jaan-boojh kar nahi liye.
* UI CDN (FontAwesome, Audiowide, Remixicon, particles.js) se load hoti hai -> animations/icons ke liye internet chahiye.
  Offline chahiye to wo files `assets/webroot/assets/` me rakh kar `index.html` ke links badal do.
* UI/branding (logo, UPI, Telegram links) original Kayroot author ke hain. Public release se pehle unki permission lo
  ya links/branding badal do.
